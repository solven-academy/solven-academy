# SOLVEN Academy — Etapa 20

**Vídeos e armazenamento**

Esta versão parte do pacote corrigido da Etapa 19 e acrescenta upload privado de vídeos e materiais, metadados MySQL, controlo de acesso por papel/dono/inscrição e uma página de teste em `/media.html`.

Leia `docs/ETAPA20-VIDEOS-ARMAZENAMENTO.md` e `RECOMECA_AQUI.txt` antes de executar.

A Etapa 19 continua por validar no ambiente do utilizador. A criação desta etapa não significa que as aulas ao vivo ou a transmissão de vídeo em tempo real tenham sido testadas.
