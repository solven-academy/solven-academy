# SOLVEN Academy — Etapa 17: SOLVEN PROTECT

Esta versão parte do projecto recebido da Etapa 16 e acrescenta o módulo de reclamações e protecção de estudante/professor.

## O que foi acrescentado
- Migração Flyway V4 para processos de reclamação e evidências descritivas.
- Abertura de reclamação pelo estudante associado à inscrição.
- Declarações separadas do estudante e do professor.
- Registo de descrições de evidências (não é upload de ficheiros).
- Consulta restrita aos dois participantes envolvidos.
- Consulta e decisão administrativa protegidas por `ROLE_ADMIN`.
- Registos de auditoria das acções.
- Nenhum movimento financeiro automático.

## Requisitos
- Java 21
- Maven
- MySQL 8 compatível com o esquema da Etapa 16
- Variáveis de ambiente e segredo JWT configurados conforme `docs/SEGURANCA.md`

## Executar
Na pasta `backend`:
```bash
mvn clean test
mvn spring-boot:run
```
A migração V4 é aplicada pelo Flyway ao iniciar a aplicação. Faça backup da base de dados antes de actualizar qualquer ambiente existente.

## Estado de verificação desta entrega
Os ficheiros foram adicionados e revistos estaticamente. Não foi possível confirmar compilação/testes Maven neste ambiente; execute os comandos acima no ambiente com Java 21, Maven e MySQL configurados antes de integrar em produção.

Consulte `docs/ETAPA17-SOLVEN-PROTECT.md` para regras e exemplos de API.
