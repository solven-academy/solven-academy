-- Executar uma vez com uma conta administrativa do MySQL 8.
CREATE DATABASE IF NOT EXISTS solven_academy
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Crie um utilizador de aplicação separado. Substitua a palavra-passe
-- por uma palavra-passe forte e exclusiva antes de executar:
-- CREATE USER 'solven_app'@'localhost' IDENTIFIED BY 'SUBSTITUA_POR_SEGREDO_FORTE';
-- GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES
--   ON solven_academy.* TO 'solven_app'@'localhost';
-- FLUSH PRIVILEGES;
