# Etapa 16 — Fundação financeira internacional

A etapa 16 evolui o modelo financeiro para moedas internacionais, prepara um livro de movimentos para professores e documenta uma arquitectura independente de fornecedores. A cobrança real permanece desligada até contratação, integração e validação legal/técnica do processador.

Ver `RECOMECA_AQUI.txt` e `docs/ETAPA16-FINANCEIRO-INTERNACIONAL.md`.

## Continuação do projecto
A Etapa 17 foi acrescentada nesta distribuição. Consulte `README-ETAPA17.md` e `docs/ETAPA17-SOLVEN-PROTECT.md`.
