# SOLVEN Academy — Etapa 16: fundação financeira internacional

## Objectivo
Preparar o modelo de dados e as regras para preços e pagamentos em várias moedas: AOA, USD, EUR, BRL, GBP, ZAR e outras. O país/moeda preferidos são uma escolha do utilizador; a localização automática nunca deve ser obrigatória.

## O que esta etapa acrescenta
- Migração Flyway V3 para preços multi-moeda, valores pagos, moeda, taxa de conversão registada, referência/idempotência e eventos de pagamento.
- Registo contabilístico de movimentos da carteira do professor, separado do saldo disponível.
- Catálogo de moedas com AOA activo por defeito e moedas internacionais inicialmente desactivadas.
- Configuração `SOLVEN_PAYMENTS_ENABLED=false` por defeito.
- Regras e contratos documentados para integrar fornecedores sem prender a aplicação a um único operador.

## Limite importante
Esta etapa NÃO processa dinheiro real, NÃO converte moedas em tempo real, NÃO confirma pagamentos e NÃO envia dinheiro a professores. Não existe ainda fornecedor contratado nem credenciais. Nunca marques um pagamento como pago com base no retorno do navegador. Só um webhook autenticado, com assinatura validada e evento idempotente, poderá confirmar um pagamento depois da integração real.

## Moeda e preços
- Guardar montante e código ISO 4217 juntos; nunca guardar apenas um número sem moeda.
- O preço original do curso é definido pelo professor numa moeda de liquidação suportada pela SOLVEN.
- A conversão para apresentação é uma cotação informativa com fonte e instante registados. O preço final é fixado no checkout e não deve mudar durante a sessão de pagamento.
- Não fazer conversão por geolocalização sem permitir alteração manual.
- Não assumir que todos os países aceitam todos os métodos ou moedas.

## Fluxo futuro de pagamento
1. API verifica utilizador, curso aprovado, matrícula e preço no servidor.
2. API cria uma tentativa `CREATED/PENDING`, com chave de idempotência.
3. Adaptador do fornecedor cria checkout e devolve URL/referência segura.
4. O estudante paga no ambiente do fornecedor.
5. Fornecedor envia webhook para SOLVEN.
6. SOLVEN valida assinatura, referência, valor, moeda, estado e repetição do evento.
7. Só então confirma pagamento e activa a matrícula numa transacção de base de dados.
8. Lançamentos de comissão e valor do professor são registados em livro contabilístico; payout só após KYC, regras de risco e disponibilidade do país.

## Arquitectura recomendada
Criar uma interface `PaymentProvider` com operações de criar checkout, verificar evento e pedir reembolso. Cada fornecedor terá um adaptador próprio. O resto da SOLVEN não deve depender de nomes ou formatos proprietários. Não armazenar PAN, CVV ou dados completos de cartões.

## Comissão
`SOLVEN_PLATFORM_FEE_BPS` representa pontos-base: 1500 = 15%. É apenas um valor de demonstração configurável. A comissão real deve ser aprovada comercialmente e mostrada ao professor antes de publicar/vender. As taxas do processador, impostos, câmbio, chargebacks e reembolsos precisam de regras próprias. Não prometer payout automático nesta fase.

## O que precisamos confirmar antes de activar um país
- País de constituição e entidade que será merchant of record (responsável legal pela venda) ou vendedor directo.
- Países aceites para onboarding da empresa e dos professores.
- Moedas de cobrança e liquidação, cartões e métodos locais.
- Regras de KYC/AML, sanções, idade, impostos, facturação e protecção do consumidor.
- Prazos, taxas, reservas, chargebacks, reembolsos e limites de payout.
- Suporte a marketplace/split payments ou pagamentos a terceiros.
- Webhooks assinados, ambiente sandbox, documentação e SLA.

## Teste da migração
1. Fazer backup da base de dados de desenvolvimento.
2. Confirmar que Flyway V1 e V2 estão aplicadas.
3. Iniciar a API com MySQL 8 e verificar a execução da V3.
4. Confirmar `courses.price_currency='AOA'` para cursos existentes.
5. Confirmar `payments.currency='AOA'` e que moedas internacionais estão `is_enabled=false`.
6. Não activar `SOLVEN_PAYMENTS_ENABLED` em produção.

## Próxima implementação
Etapa posterior: seleccionar e contratar um fornecedor que aceite a entidade legal e os países pretendidos; implementar sandbox, checkout, webhooks assinados, reconciliação, reembolsos e payouts antes de cobrar clientes.
