# SOLVEN Academy — Etapa 11: MySQL

## Objectivo
Ligar a API da Etapa 10 a uma base de dados MySQL 8 para que os registos deixem de depender da memória do navegador ou de listas temporárias.

## O que esta etapa faz
- Usa MySQL Connector/J para comunicar com MySQL.
- Usa Flyway para executar a migração `V1__create_solven_schema.sql` uma única vez e registar a versão aplicada.
- Cria as tabelas do modelo inicial: utilizadores, perfis, categorias, cursos, aulas, inscrições, pagamentos, avaliações e registos de auditoria.
- Insere categorias iniciais.
- Mantém `spring.jpa.hibernate.ddl-auto=validate`: Hibernate verifica se as entidades correspondem ao esquema, mas não altera tabelas automaticamente.
- `/api/health` executa `SELECT 1`; `database: UP` confirma uma consulta real.

## Preparação do MySQL
1. Instale e inicie MySQL 8 num computador/servidor. MySQL não é o Maven e não é instalado por `mvn`.
2. Abra um cliente MySQL como administrador e execute `database/create-database.sql` depois de rever e adaptar os comandos comentados para criar o utilizador `solven_app`.
3. Não utilize `root` na aplicação. Dê ao utilizador da aplicação apenas permissões necessárias. A migração precisa de permissões de criação/alteração durante a instalação inicial; depois, reveja e reduza as permissões.
4. Configure as variáveis de ambiente descritas abaixo.

## Variáveis de ambiente
- `SOLVEN_DB_URL`: URL JDBC. Exemplo local: `jdbc:mysql://localhost:3306/solven_academy?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Africa/Luanda`.
- `SOLVEN_DB_USER`: por exemplo `solven_app`.
- `SOLVEN_DB_PASSWORD`: palavra-passe MySQL forte.
- `SOLVEN_JWT_SECRET`: segredo aleatório forte com pelo menos 32 bytes. Não publique no GitHub nem o envie em mensagens.

`useSSL=false` no valor predefinido é apenas para desenvolvimento local. Em servidor remoto, configure TLS/SSL com certificado validado; não copie a configuração local para produção.

## Executar
Na pasta `backend`:

```bash
mvn spring-boot:run
```

Depois abra `http://localhost:8080/api/health`. Espera-se JSON com `status: UP` e `database: UP`.

## Se falhar
- `Communications link failure`: MySQL não está iniciado, host/porta errados ou inacessíveis.
- `Access denied`: utilizador ou palavra-passe/permissões incorrectos.
- `Unknown database`: execute a criação da base de dados.
- Erro de validação Hibernate: o esquema não corresponde à entidade; não apague tabelas para tentar corrigir. Consulte a mensagem e faça backup antes de qualquer alteração.
- Falha ao descarregar dependências: problema de rede ou repositório Maven.

## Limites
Esta etapa não é uma implantação de produção. Não inclui backup automático, monitorização operacional, recuperação de desastre, migrações de dados reais, painel de gestão, recuperação de palavra-passe, confirmação de email, MFA ou integração da interface web. Não armazene dados reais de estudantes até concluir revisão de segurança, privacidade, consentimento e testes. Os pagamentos continuam fora desta etapa.
