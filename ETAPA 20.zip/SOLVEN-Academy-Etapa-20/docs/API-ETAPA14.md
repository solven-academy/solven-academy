# API administrativa — Etapa 14

Todas as rotas abaixo exigem `Authorization: Bearer <JWT>` de uma conta ADMIN activa.

- `GET /api/admin/dashboard`
- `GET /api/admin/courses/pending`
- `POST /api/admin/courses/{id}/review` com `{"decision":"APPROVE"}`
- `POST /api/admin/courses/{id}/review` com `{"decision":"REJECT","reason":"Motivo detalhado com pelo menos 10 caracteres"}`
- `GET /api/admin/users`
- `PATCH /api/admin/users/{id}/status` com `{"status":"SUSPENDED"}` ou `{"status":"ACTIVE"}`
- `GET /api/admin/activity`

Os utilizadores não recebem campos de palavra-passe nas respostas. O endpoint de listagem é apenas para ADMIN.
