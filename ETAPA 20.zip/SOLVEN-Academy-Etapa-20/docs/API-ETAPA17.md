# API — Etapa 17 SOLVEN PROTECT

Base: `/api`. Requer `Authorization: Bearer <JWT>`.

| Método | Rota | Permissão |
|---|---|---|
| POST | `/student/protection-cases` | estudante dono da inscrição |
| GET | `/protection-cases/mine` | participante autenticado |
| POST | `/protection-cases/{id}/statement` | estudante ou professor do processo |
| POST | `/protection-cases/{id}/evidence` | estudante ou professor do processo |
| GET | `/protection-cases/{id}/evidence` | estudante ou professor do processo |
| GET | `/admin/protection-cases` | ADMIN |
| PATCH | `/admin/protection-cases/{id}/review` | ADMIN |

Os DTOs e exemplos completos estão em `ETAPA17-SOLVEN-PROTECT.md`.
