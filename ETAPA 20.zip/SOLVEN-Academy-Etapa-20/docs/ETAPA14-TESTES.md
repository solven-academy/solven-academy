# Testes manuais — Etapa 14

1. Criar o primeiro ADMIN com as variáveis de ambiente descritas em `RECOMECA_AQUI.txt`.
2. Iniciar o backend e abrir `/admin.html`.
3. Tentar entrar com uma conta STUDENT ou TEACHER: o painel deve recusar.
4. Entrar com ADMIN: os indicadores e as listas devem carregar.
5. Criar um curso com uma conta TEACHER: deve surgir em pendentes.
6. Aprovar um curso: deixa de aparecer na fila e fica disponível no catálogo público.
7. Rejeitar outro curso sem motivo válido: a API deve devolver erro; com motivo de 10+ caracteres, deve rejeitar e guardar o motivo.
8. Suspender uma conta de teste: os pedidos autenticados dessa conta devem deixar de ser autorizados.
9. Reactivar a conta e confirmar que pode voltar a autenticar-se.
10. Consultar a actividade e confirmar os registos das acções administrativas.
11. Tentar POST `/api/auth/register` com `role: "ADMIN"`: deve devolver 403.
12. Tentar chamar `/api/admin/dashboard` sem token ou com token de estudante: deve ser recusado.

Não executar os testes com contas ou dados pessoais reais. Usar uma base de dados local de teste.
