# Etapa 20 — Vídeos e armazenamento

## Objectivo
Adicionar armazenamento privado de vídeos de aulas e materiais dos cursos, preservando as etapas anteriores.

## Funcionalidades incluídas
- Upload autenticado para um curso por professor responsável ou administrador.
- Tipos permitidos: MP4, WebM, PDF, JPG, PNG e WEBP.
- Limite de 500 MB por ficheiro (configurável no servidor).
- Metadados no MySQL; ficheiros binários fora da pasta pública, com chave aleatória.
- Listagem e acesso apenas pelo professor do curso, administrador ou estudante com inscrição ACTIVE/COMPLETED num curso APPROVED.
- Eliminação pelo professor que enviou o ficheiro ou por administrador.
- Resposta de ficheiro com `nosniff` e tipo MIME guardado.
- Interface de teste em `/media.html`.

## API
- `POST /api/courses/{courseId}/media` — multipart/form-data, campo `file`.
- `GET /api/courses/{courseId}/media` — lista materiais autorizados.
- `GET /api/courses/{courseId}/media/{mediaId}/content` — abre o conteúdo autorizado.
- `DELETE /api/courses/{courseId}/media/{mediaId}` — remove o ficheiro e os metadados.

Todas as rotas exigem JWT. O upload exige papel TEACHER (dono do curso) ou ADMIN. O acesso de estudante exige curso APPROVED e inscrição ACTIVE ou COMPLETED.

## Configuração
`SOLVEN_MEDIA_STORAGE_DIR` define a pasta privada de armazenamento (padrão `./solven-storage`). Mantém-na fora de `static`, fora do controlo de versões e em volume persistente com permissões restritas. Configura `SOLVEN_MEDIA_MAX_FILE_SIZE` e `SOLVEN_MEDIA_MAX_REQUEST_SIZE` conforme a infraestrutura.

## Teste
1. Inicia MySQL e configura as variáveis da base de dados e JWT conforme `backend/README.md`.
2. Inicia o backend. Flyway aplica `V7__video_storage_and_course_media.sql`.
3. Entra como professor e cria/usa um curso que lhe pertença.
4. Abre `http://localhost:8080/media.html`, cola o JWT, informa o ID do curso e envia um MP4 pequeno ou PDF.
5. Carrega a lista e abre o material. Testa também com estudante inscrito e estudante sem inscrição: o segundo deve receber 403.
6. Confirma que o ficheiro foi guardado na pasta privada indicada e que não está acessível por URL estática.

## Limitações e produção
- Esta etapa usa armazenamento local para desenvolvimento e testes; não é armazenamento distribuído nem CDN. Em produção, recomenda-se armazenamento de objectos privado (ex.: S3 compatível), URLs temporárias assinadas, antivírus, quotas por utilizador/curso, monitorização, backups e política de retenção.
- A validação MIME usa o tipo enviado pelo cliente e não substitui inspecção real de conteúdo; antes de produção, adicionar detecção por assinatura/magic bytes e análise antimalware.
- A transmissão adaptativa (HLS/DASH), transcodificação, legendas e CDN não estão incluídas.
- O endpoint usa streaming do ficheiro do disco; não carrega o vídeo inteiro na memória.
- O token guardado pela página de teste fica em localStorage: usar apenas num dispositivo pessoal e remover depois dos testes. A página é uma ferramenta de desenvolvimento, não um fluxo de autenticação final.
