# Contrato inicial da API

- `GET /api/health` — verifica API e consulta MySQL (`SELECT 1`).
- `POST /api/auth/register` — cria conta de estudante ou professor.
- `POST /api/auth/login` — autentica e devolve token JWT.
- `GET /api/me` — devolve identidade da sessão autenticada; requer `Authorization: Bearer <accessToken>`.

Os pedidos de registo/login e respectivos campos estão definidos nos DTOs Java em `backend/src/main/java/ao/solven/api/auth/`. Não inclua a palavra-passe nem o hash na resposta pública.
