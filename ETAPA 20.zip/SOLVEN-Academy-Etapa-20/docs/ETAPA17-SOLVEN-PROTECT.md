# Etapa 17 — SOLVEN PROTECT

## Objectivo
Criar um fluxo auditável e imparcial para reclamações relacionadas com cursos/aulas adquiridos através de uma inscrição. O estudante pode abrir o processo; estudante e professor podem apresentar declarações e registar referências descritivas de evidências; um administrador analisa e regista uma decisão fundamentada.

## Regras de protecção
- O estudante só pode abrir reclamação sobre uma inscrição sua.
- O professor associado ao curso é identificado pelo servidor; o cliente não escolhe o professor.
- Uma inscrição não pode ter mais de um processo activo em simultâneo.
- Apenas o estudante e o professor envolvidos podem consultar o processo, apresentar declaração e consultar evidências.
- Só ADMIN pode consultar todos os processos e registar a decisão.
- As declarações e decisões são registadas no histórico de auditoria.
- Uma reclamação não prova automaticamente que qualquer participante tem razão. A decisão deve considerar as declarações e as evidências disponíveis.
- Não há reembolso, transferência, retenção bancária ou alteração automática da carteira nesta etapa. `financial_action` permanece `NONE`. Qualquer acção financeira futura depende do contrato, autorização e API do parceiro financeiro, além de revisão legal.
- Não gravar aulas por defeito. Qualquer gravação exige informação e consentimento adequados.

## Estados
`OPEN`, `UNDER_REVIEW`, `WAITING_FOR_STUDENT`, `WAITING_FOR_TEACHER`, `RESOLVED_STUDENT`, `RESOLVED_TEACHER`, `CLOSED`.

## Endpoints
Todos exigem JWT, excepto rotas públicas já existentes.

### Estudante
`POST /api/student/protection-cases`
```json
{"enrollmentId": 12, "claimType": "LESSON_NOT_DELIVERED", "description": "A aula comprada não foi realizada.", "requestedResolution": "Peço análise e eventual reembolso conforme as regras."}
```
`GET /api/protection-cases/mine`

### Estudante ou professor envolvidos
`POST /api/protection-cases/{id}/statement`
```json
{"statement": "Apresento a minha descrição dos acontecimentos..."}
```
`POST /api/protection-cases/{id}/evidence`
```json
{"description": "Comprovativo de presença guardado para análise."}
```
`GET /api/protection-cases/{id}/evidence`

Nesta versão, o endpoint regista apenas a descrição da evidência. Upload, antivírus, armazenamento privado e URLs assinados ainda não estão implementados; não enviar documentos sensíveis nem links públicos.

### Administrador
`GET /api/admin/protection-cases`
`PATCH /api/admin/protection-cases/{id}/review`
```json
{"status": "WAITING_FOR_TEACHER", "decision": "Solicitada declaração do professor antes da decisão final."}
```
A decisão final pode usar `RESOLVED_STUDENT`, `RESOLVED_TEACHER` ou `CLOSED`. A aplicação regista a decisão, mas não executa operação financeira.

## Migração
Flyway executa `V4__solven_protect.sql` depois das migrações anteriores. Não executar manualmente numa base de dados já gerida pelo Flyway.

## Limitações e trabalho pendente
- Sem upload real de evidências ou armazenamento de ficheiros.
- Sem integração com chat, videochamada, presença ou gravação de aula.
- Sem relógio/SLA de resposta nem notificações.
- Sem integração de reembolso, bloqueio de fundos ou payout.
- Sem portal jurídico, política formal de disputas ou recurso em segunda instância.
- A autenticação e as permissões existentes devem ser testadas no ambiente completo antes de produção.
