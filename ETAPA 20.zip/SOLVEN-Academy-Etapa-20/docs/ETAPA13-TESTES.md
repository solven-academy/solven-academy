# Etapa 13 — Lista de testes

- [ ] API inicia com JDK 21, Maven e MySQL configurados.
- [ ] GET /api/categories devolve categorias activas sem autenticação.
- [ ] GET /api/courses não mostra cursos pendentes/rejeitados.
- [ ] Professor autenticado cria curso e recebe HTTP 201.
- [ ] Curso criado fica PENDING.
- [ ] Professor só vê os próprios cursos.
- [ ] Estudante recebe HTTP 403 ao tentar criar curso.
- [ ] Curso PENDING não pode ser consultado pela rota pública.
- [ ] Título/descrição/preço/categoria inválidos são rejeitados.
- [ ] Reiniciar a API não apaga os cursos guardados no MySQL.
