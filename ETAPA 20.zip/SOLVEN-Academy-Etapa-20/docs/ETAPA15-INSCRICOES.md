# Etapa 15 — Inscrições e matrículas

## Objectivo
Permitir que estudantes se inscrevam em cursos aprovados, consultem o seu histórico e que cada professor consulte a lista de estudantes inscritos nos seus próprios cursos.

## Regras implementadas
- Só contas com papel `STUDENT` podem criar inscrições.
- Só cursos com estado `APPROVED` podem receber inscrições.
- Uma conta não pode inscrever-se duas vezes no mesmo curso.
- Cursos gratuitos (`priceAoa = 0`) geram inscrição `ACTIVE`.
- Cursos pagos geram inscrição `PENDING`. **Não há pagamento nesta etapa**; não se deve conceder acesso ao conteúdo pago enquanto a inscrição estiver pendente.
- Um professor só pode consultar estudantes de um curso que lhe pertence.
- Todas as rotas abaixo exigem token JWT válido.

## Endpoints

### Criar inscrição
`POST /api/student/enrollments/{courseId}`

Exemplo:
```http
Authorization: Bearer <TOKEN_DO_ESTUDANTE>
POST /api/student/enrollments/12
```

Resposta: inclui `enrollmentId`, curso, preço, `status` e `nextStep`.

### Histórico do estudante
`GET /api/student/enrollments`

Devolve as inscrições do estudante autenticado, da mais recente para a mais antiga.

### Lista de estudantes de um curso (professor)
`GET /api/teacher/courses/{courseId}/students`

Só o professor proprietário do curso pode consultar a lista. A resposta inclui nome, email, estado e data da inscrição.

## Estados
- `PENDING`: aguarda confirmação de pagamento (cursos pagos).
- `ACTIVE`: inscrição activa (nesta etapa, cursos gratuitos).
- `CANCELLED`: cancelada; não é atribuída automaticamente.
- `COMPLETED`: concluída; não é atribuída automaticamente.

## Migração
O Flyway executa `V2__enrollments.sql` ao iniciar a aplicação. A tabela `enrollments` já é criada pela migração inicial V1; V2 acrescenta o índice para consultas por curso e estado. Não executes V2 manualmente se Flyway já a tiver aplicado.

## Teste manual
1. Inicia MySQL e a API, conforme `RECOMECA_AQUI.txt`.
2. Regista uma conta `STUDENT` e uma conta `TEACHER`.
3. Com o professor, cria um curso e pede ao administrador para o aprovar no painel.
4. Obtém o token JWT do estudante através de `/api/auth/login`.
5. Envia `POST /api/student/enrollments/{id-do-curso}` com o token do estudante.
6. Consulta `GET /api/student/enrollments`.
7. Com o token do professor proprietário, consulta `GET /api/teacher/courses/{id-do-curso}/students`.
8. Tenta repetir a inscrição e confirma que a API responde `409 Conflict`.

## Limitações desta etapa
- Ainda não existe integração com gateway de pagamentos; inscrições pagas ficam `PENDING`.
- Ainda não existe cancelamento, reembolso, emissão de certificados ou controlo de progresso nesta API.
- A lista de estudantes é visível apenas ao professor proprietário; proteger também o acesso operacional e os dados em produção.
- Não usar dados reais de menores ou pagamentos reais antes de revisão jurídica, privacidade, segurança e testes de ponta a ponta.
