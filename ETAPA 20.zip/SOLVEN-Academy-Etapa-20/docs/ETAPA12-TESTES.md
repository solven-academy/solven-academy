# Checklist de testes da Etapa 12

- [ ] MySQL inicia e aceita a ligação da aplicação.
- [ ] `GET /api/health` devolve `status: UP` e `database: UP`.
- [ ] Registo de estudante cria conta e abre a área pessoal.
- [ ] Registo de professor cria conta e apresenta o papel PROFESSOR.
- [ ] Email duplicado é recusado.
- [ ] Login com palavra-passe errada é recusado.
- [ ] `/api/me` funciona com token válido.
- [ ] `/api/me` sem token é recusado.
- [ ] Terminar sessão remove a sessão do separador.

Estes testes devem ser executados no ambiente local antes de qualquer publicação.
