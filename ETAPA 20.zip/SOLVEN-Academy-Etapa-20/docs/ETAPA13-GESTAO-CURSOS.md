# Etapa 13 — Gestão de cursos no servidor

## Objectivo
Ligar a criação e consulta de cursos ao Spring Boot e ao MySQL, com controlo de acesso por papel.

## Funcionalidades
- Consulta pública das categorias activas.
- Consulta pública apenas dos cursos com estado `APPROVED`.
- Criação de cursos por contas com papel `TEACHER`.
- Cada curso fica associado ao professor autenticado; o cliente não pode escolher o `teacher_id`.
- Cursos criados ficam em `PENDING` e não são apresentados no catálogo público.
- O professor consulta apenas os seus cursos.
- Validação do título, descrição, categoria, nível e preço.

## API
| Método | Caminho | Acesso |
|---|---|---|
| GET | `/api/categories` | Público |
| GET | `/api/courses` | Público; apenas aprovados |
| GET | `/api/courses/{id}` | Público; apenas aprovados |
| POST | `/api/teacher/courses` | JWT e papel TEACHER |
| GET | `/api/teacher/courses` | JWT e papel TEACHER |

### Exemplo de criação
```json
{
  "title": "Introdução à programação",
  "description": "Aprende os fundamentos da programação desde o início.",
  "categoryId": 1,
  "level": "BEGINNER",
  "priceAoa": 2500.00
}
```

## Regras de segurança
- A identidade do professor é obtida do JWT validado no servidor.
- O servidor rejeita criação por utilizadores que não tenham papel `TEACHER`.
- Não existe endpoint público para mudar o estado de um curso.
- Não se aceita `teacherId` nem `status` enviados pelo navegador.
- Os detalhes de cursos não aprovados não são expostos pela rota pública.

## Limitações
- A aprovação/rejeição administrativa fica para uma etapa posterior. Não alteres o estado manualmente em produção.
- Ainda não há upload de vídeo/documentos, pagamentos, inscrições, avaliações ou streaming.
- Não há testes de integração executados contra uma instância MySQL nesta entrega. Executa a lista de testes abaixo no teu ambiente.

## Testes manuais
1. Inicia MySQL e configura as variáveis documentadas na Etapa 11.
2. Inicia a API com `mvn spring-boot:run`.
3. Regista uma conta `TEACHER` e copia o `accessToken` devolvido.
4. Faz `GET /api/categories` sem token: deve devolver categorias.
5. Faz `POST /api/teacher/courses` com `Authorization: Bearer <token>`: deve devolver HTTP 201 e `status: PENDING`.
6. Faz `GET /api/teacher/courses` com o token: deve listar o curso criado.
7. Faz `GET /api/courses`: o curso pendente não deve aparecer.
8. Regista uma conta `STUDENT` e tenta `POST /api/teacher/courses`: deve devolver HTTP 403.
9. Tenta abrir `/api/courses/{id}` para um curso pendente: deve devolver HTTP 404.

## Próxima etapa
Etapa 14 — Revisão administrativa de cursos: aprovação, rejeição com motivo e histórico de moderação, com contas administrativas provisionadas de forma segura.
