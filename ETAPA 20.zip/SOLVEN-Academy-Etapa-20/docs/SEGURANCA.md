# Segurança — requisitos antes de produção

## Contas e autenticação
- Hash de palavra-passe com algoritmo apropriado (por exemplo BCrypt/Argon2); nunca guardar palavra-passe em texto simples.
- MFA para administradores e, idealmente, para professores.
- Tokens/sessões com expiração, rotação e revogação.
- Recuperação de conta com token aleatório, curto prazo e uso único.
- Limitar tentativas de login e detectar padrões anormais.

## Autorização
- Verificar permissões no servidor em cada pedido.
- Não confiar em `role`, `userId`, `price` ou `status` enviados pelo browser.
- ADMIN só pode ser atribuído por processo interno protegido.
- Professores só podem gerir os seus próprios cursos.
- Estudantes só acedem a conteúdos autorizados.

## Dados e pagamentos
- HTTPS obrigatório.
- Segredos e credenciais em variáveis de ambiente/gestor de segredos.
- Não guardar números completos de cartões nem códigos de segurança.
- Confirmar pagamentos por webhook assinado e validar duplicados.
- Minimizar dados pessoais; definir retenção e eliminação.
- Backups cifrados e testes de recuperação.

## Operação
- Registo de auditoria para acções sensíveis.
- Monitorização, alertas e plano de resposta a incidentes.
- Actualizações regulares de dependências.
- Testes de segurança e revisão independente antes do lançamento.
- Protecção específica de menores, privacidade e conteúdos adequados à idade.

Esta lista é uma orientação de engenharia, não uma certificação de segurança nem aconselhamento jurídico.
