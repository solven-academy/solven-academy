# Etapa 18 — SOLVIA AI

## Objectivo
Assistente educativo com identidade SOLVEN, para estudantes e professores. A marca SOLVIA não significa que a SOLVEN treinou um modelo-base próprio: nesta versão o backend comunica com um fornecedor externo compatível com Chat Completions.

## Incluído
- API autenticada `POST /api/solvia/chat`.
- Histórico privado por utilizador: `GET /api/solvia/conversations` e `GET /api/solvia/conversations/{id}/messages`.
- Instruções diferentes para estudante, professor e administrador.
- Limite de 4.000 caracteres por mensagem e contexto limitado às últimas 12 mensagens.
- Interface em `GET /solvia.html`.
- Migração Flyway V5.
- Integração desligada por padrão.

## Configuração do fornecedor
Definir no ambiente do servidor (nunca no JavaScript, HTML, Git ou aplicação móvel):
- `SOLVEN_SOLVIA_ENABLED=true`
- `SOLVEN_SOLVIA_ENDPOINT=https://api.openai.com/v1/chat/completions` ou endpoint compatível contratado
- `SOLVEN_SOLVIA_API_KEY=<segredo>`
- `SOLVEN_SOLVIA_MODEL=<modelo contratado>`

A chave é segredo de servidor. Não a partilhar com alunos, professores nem repositório. O fornecedor escolhido deve ser avaliado quanto a tratamento de dados, localização, retenção, idade mínima, custos e termos.

## Privacidade e segurança
As conversas são guardadas na base de dados e associadas à conta autenticada. Implementar política de retenção/apagamento, consentimento e aviso de privacidade antes de produção. Não enviar dados pessoais desnecessários ao fornecedor. Não usar conversas para treinar modelos sem consentimento e base legal apropriada. Adicionar rate limiting, limites de custo e moderação antes de abrir a funcionalidade a todos.

## Limitações conhecidas
- Não há treino de modelo próprio nem fine-tuning.
- O histórico ainda não tem interface visual para navegar conversas anteriores.
- Não há streaming, voz, upload de documentos ou limites de utilização por plano.
- A disponibilidade depende do fornecedor externo e de credenciais válidas.
- O serviço permanece desativado por padrão.

## Testes manuais
1. Executar a migração V5 numa cópia de teste da base de dados.
2. Iniciar sessão e confirmar que `/solvia.html` abre.
3. Sem configuração, `POST /api/solvia/chat` deve responder 503 sem revelar segredos.
4. Configurar um fornecedor de teste e verificar resposta de estudante e professor.
5. Tentar abrir conversa de outro utilizador: deve responder 404.
6. Enviar mensagem acima de 4.000 caracteres: deve responder 400.
7. Confirmar que a chave API não aparece no frontend nem nos logs.

## Estado
Implementação inicial criada. Maven não estava disponível neste ambiente; compilação e testes de integração ficam por executar. Não activar em produção antes de revisão de segurança, privacidade, custos e testes.
