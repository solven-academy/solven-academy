# Lista de verificação da Etapa 11

- [ ] MySQL 8 está iniciado e aceita ligações.
- [ ] A base `solven_academy` existe.
- [ ] O utilizador `solven_app` consegue ligar-se à base.
- [ ] Variáveis `SOLVEN_DB_*` e `SOLVEN_JWT_SECRET` estão definidas.
- [ ] `mvn spring-boot:run` inicia sem erros.
- [ ] `GET /api/health` devolve `status: UP` e `database: UP`.
- [ ] Registar um utilizador de teste e confirmar que aparece na tabela `users`.
- [ ] Reiniciar a API e confirmar que o utilizador continua na base.
- [ ] Testar login e `GET /api/me` com o token.

Use apenas contas e dados fictícios durante os testes.
