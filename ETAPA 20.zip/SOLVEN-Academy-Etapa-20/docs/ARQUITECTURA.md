# Arquitectura técnica — SOLVEN Academy

## 1. Visão geral

A solução será dividida em três partes:

1. **Frontend:** páginas HTML, CSS e JavaScript que o estudante/professor utiliza.
2. **Backend:** aplicação Java Spring Boot que valida pedidos, aplica regras e controla permissões.
3. **Base de dados:** MySQL, que guarda utilizadores, cursos, aulas, inscrições e transacções.

O navegador nunca deve decidir quem é administrador nem aprovar pagamentos. O servidor é a autoridade.

## 2. Diagrama textual

Estudante / Professor / Administração
        |
        v
Frontend SOLVEN (HTTPS)
        |
        v
API Java (Spring Boot)
        |
        +---- Autenticação e autorização
        +---- Regras de cursos e inscrições
        +---- Integração futura com pagamentos
        +---- Registos de auditoria
        |
        v
MySQL (rede privada, sem acesso público directo)

Ficheiros de vídeo/documentos devem futuramente ficar num serviço de armazenamento de objectos, com links temporários e permissões; não devem ser guardados como grandes blocos na tabela de cursos.

## 3. Papéis

- STUDENT: procurar cursos, inscrever-se e acompanhar aprendizagem.
- TEACHER: gerir os próprios cursos e aulas.
- ADMIN: moderar cursos, gerir contas e consultar operações administrativas.

O papel é atribuído/validado pelo backend. O formulário público nunca permite escolher ADMIN.

## 4. Entidades principais

- users: credenciais, e-mail, papel e estado.
- student_profiles / teacher_profiles: dados específicos de cada perfil.
- courses: catálogo e estado de moderação.
- lessons: aulas pertencentes a um curso.
- enrollments: inscrição de estudante num curso.
- payments: referência e estado de pagamento, sem guardar dados de cartão.
- reviews: avaliação após uma inscrição válida.
- audit_logs: histórico de acções administrativas.

## 5. Estados de curso

DRAFT -> PENDING -> APPROVED ou REJECTED.
Um professor só pode editar os seus cursos. Um curso aprovado pode voltar a PENDING se sofrer uma alteração que exija nova revisão.

## 6. Regras de negócio essenciais

- Um professor só altera cursos que lhe pertencem.
- Um estudante só acede ao conteúdo de cursos em que está inscrito e com pagamento confirmado, quando aplicável.
- Um curso rejeitado não aparece no catálogo público.
- Uma conta suspensa não inicia sessão nem faz operações.
- Acções administrativas ficam registadas.
- Pagamentos devem ser confirmados pelo servidor através de notificações verificadas do provedor, nunca por um botão do navegador.
- Nunca confiar em preço, papel, estado ou e-mail enviados pelo frontend sem validação.

## 7. Ambientes

- Desenvolvimento: computador local.
- Testes: ambiente separado, com dados fictícios.
- Produção: servidor com HTTPS, segredos fora do código, backups e monitorização.

Não publicar esta base inicial como serviço de produção sem completar autenticação, autorização, validações, testes e revisão de segurança.
