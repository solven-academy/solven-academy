# Etapa 12 — Integração do website com o servidor

## Fluxo implementado
1. O navegador abre a página estática servida pelo Spring Boot.
2. O formulário envia JSON para `POST /api/auth/register` ou `POST /api/auth/login`.
3. O backend valida os dados, consulta MySQL e devolve um JWT.
4. O frontend guarda o token em `sessionStorage` e envia `Authorization: Bearer <token>` para `GET /api/me`.
5. O backend valida o token e devolve nome, email e papel da conta.

## Teste manual
- Abrir `http://localhost:8080`.
- Criar uma conta de teste com palavra-passe de pelo menos 12 caracteres.
- Confirmar que a área pessoal apresenta nome, email e papel.
- Terminar sessão e entrar novamente.
- Testar uma conta de estudante e uma de professor.

## Limites e segurança
- Token em `sessionStorage` é uma solução de integração inicial; uma aplicação de produção deve avaliar cookies `HttpOnly`, `Secure` e `SameSite`, proteção CSRF adequada e política CSP rigorosa.
- Servir frontend e API na mesma origem evita configurar CORS nesta etapa.
- Não guardar palavras-passe no frontend nem no `localStorage`.
- Não existe ainda recuperação/validação de email, MFA, gestão de consentimento, perfis completos ou permissões administrativas.
- Não foi implementado CRUD de cursos nesta etapa.
- Nunca colocar segredos reais no GitHub. Definir credenciais por variáveis de ambiente e usar TLS em produção.

## Erros comuns
- `Connection refused` ou erro de datasource: MySQL não está ligado ou as credenciais estão erradas.
- Erro de chave JWT: definir `SOLVEN_JWT_SECRET` antes de iniciar a API.
- `Email já registado`: usar outro email de teste ou entrar na conta existente.
- Página não abre: confirmar que Maven continua em execução e usar `http://localhost:8080`.
