# Etapa 10 — Registo, início de sessão e autenticação

## O que foi implementado
- Registo de contas de estudante e professor pela API.
- Email normalizado para minúsculas e verificação de duplicados.
- Palavra-passe armazenada com BCrypt (hash, não texto simples).
- Início de sessão com verificação segura da palavra-passe.
- Token JWT assinado, com validade curta (15 minutos por padrão).
- Endpoint `/api/me` protegido por token.
- Contas suspensas ou pendentes não conseguem iniciar sessão.
- Não existe registo público de administrador: a função ADMIN não é aceite no pedido de registo.

## Teste local
Registo (JSON):
```json
{"fullName":"Aluno de Teste","email":"aluno@exemplo.ao","password":"UmaSenhaForte123!","role":"STUDENT"}
```
Login:
```json
{"email":"aluno@exemplo.ao","password":"UmaSenhaForte123!"}
```
Use o `accessToken` devolvido para chamar `GET /api/me` com o cabeçalho `Authorization: Bearer <token>`.

## Limitações e segurança
Esta API ainda não tem refresh token, verificação de email, recuperação de palavra-passe, MFA, rate limiting, detecção de abuso, autorização por propriedade dos recursos nem integração com frontend. O segredo JWT e as credenciais MySQL têm de ser fornecidos por variáveis de ambiente e mantidos fora do repositório. Exigir HTTPS em qualquer ambiente público. Antes de produção, fazer revisão independente e testes de segurança.
