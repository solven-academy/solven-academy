# Contrato financeiro — Etapa 16

Esta etapa define o contrato alvo; os endpoints de cobrança não são expostos enquanto `solven.payments.enabled=false`.

## Rotas planeadas
- `GET /api/finance/currencies` — lista moedas activas e metadados.
- `GET /api/finance/quote?amount=...&from=AOA&to=EUR` — cotação informativa, com fonte e validade (só depois de integrar fonte FX).
- `POST /api/payments/checkout` — cria tentativa e checkout do fornecedor; autenticado, estudante.
- `POST /api/payments/webhooks/{provider}` — webhook público mas protegido por assinatura e validação estrita.
- `GET /api/payments/mine` — histórico do estudante autenticado.
- `GET /api/teacher/wallet` — movimentos e saldos contabilísticos do próprio professor.
- `POST /api/admin/payments/{id}/refund` — reembolso autorizado e auditado.

## Regras obrigatórias
- O servidor determina o preço; nunca confiar no valor enviado pelo browser.
- Idempotência em criação de checkout e processamento de webhook.
- Verificar assinatura do webhook sobre o corpo bruto, timestamp e prevenção de replay.
- Comparar exactamente valor, moeda, merchant account e referência.
- Não revelar dados de pagamento de outro utilizador.
- Não armazenar dados sensíveis de cartões.
- Toda alteração financeira gera registo de auditoria imutável.
