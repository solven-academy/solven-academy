# API — Etapa 15

| Método | Rota | Papel | Resultado |
|---|---|---|---|
| POST | `/api/student/enrollments/{courseId}` | STUDENT | Cria inscrição em curso aprovado |
| GET | `/api/student/enrollments` | STUDENT | Histórico do estudante autenticado |
| GET | `/api/teacher/courses/{courseId}/students` | TEACHER proprietário | Lista de estudantes daquele curso |

Todas as rotas exigem `Authorization: Bearer <JWT>`. A API valida o papel no serviço e verifica a propriedade do curso antes de mostrar a lista de estudantes.
