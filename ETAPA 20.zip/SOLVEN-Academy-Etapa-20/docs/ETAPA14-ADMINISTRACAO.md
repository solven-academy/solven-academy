# Etapa 14 — Administração e moderação

## Objectivo
Criar uma área restrita para administrar a plataforma e moderar cursos submetidos por professores.

## Autorização
O papel `ADMIN` foi adicionado ao enum. O registo público recusa explicitamente esse papel. As rotas `/api/admin/**` exigem a autoridade `ROLE_ADMIN`, gerada pelo filtro JWT a partir do papel guardado na base de dados. O primeiro administrador só é criado pelo bootstrap com `SOLVEN_ADMIN_EMAIL` e `SOLVEN_ADMIN_PASSWORD` no ambiente do servidor.

## Funcionalidades
- Resumo de utilizadores e estados dos cursos.
- Fila de cursos `PENDING`.
- Aprovar curso ou rejeitar com motivo de pelo menos 10 caracteres.
- Consultar contas e suspender/reactivar contas não administrativas.
- Impedir auto-suspensão e suspensão do último administrador activo.
- Registar acções na tabela `audit_logs`.
- Interface web em `/admin.html`.

## Rotas
| Método | Rota | Função |
|---|---|---|
| GET | `/api/admin/dashboard` | Indicadores |
| GET | `/api/admin/courses/pending` | Cursos pendentes |
| POST | `/api/admin/courses/{id}/review` | Aprovar/rejeitar |
| GET | `/api/admin/users` | Listar contas |
| PATCH | `/api/admin/users/{id}/status` | Suspender/reactivar |
| GET | `/api/admin/activity` | Últimas 50 acções |

## Exemplos JSON
Aprovação: `{"decision":"APPROVE"}`

Rejeição: `{"decision":"REJECT","reason":"A descrição não explica os objectivos do curso."}`

Suspensão: `{"status":"SUSPENDED"}`

Reactivação: `{"status":"ACTIVE"}`

## Limitações
Não foi implementada a verificação de professores porque o fluxo de submissão de documentos e revisão de qualificações ainda não existe. Denúncias, notificações, relatórios exportáveis e gestão financeira ficam para etapas futuras. O painel é uma base inicial, não um produto pronto para produção.
