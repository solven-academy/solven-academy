# Etapa 19 — SOLVEN LIVE

## Objectivo
Criar a base segura de agendamento e controlo de aulas ao vivo, integrada com contas, cursos e inscrições já existentes.

## Incluído nesta etapa
- Professores podem agendar sessões apenas para cursos aprovados que lhes pertencem.
- Validação de datas e horas (fim posterior ao início; não aceitar início no passado).
- Estudantes só consultam sessões dos cursos em que têm inscrição ACTIVE.
- Entrada na sala exige autenticação e inscrição activa; o professor responsável também pode entrar.
- Estados: SCHEDULED, LIVE, ENDED e CANCELLED.
- Registo de participantes e contagem de participantes.
- Professor pode iniciar, terminar ou cancelar a sua sessão.
- Interface integrada no painel da SOLVEN.
- Migração Flyway V6 para sessões e participantes.

## Limite técnico importante
Esta etapa implementa agenda, autorização e controlo lógico da sala. **Ainda não transmite áudio/vídeo**, não partilha ecrã, não tem quadro branco, chat em tempo real ou gravação. A resposta da sala indica `mediaStatus=NOT_CONFIGURED`. Para vídeo real será necessário integrar e testar um serviço WebRTC/SFU (por exemplo, uma infraestrutura própria ou fornecedor contratado), com credenciais temporárias, TURN, limites de participantes, consentimento e políticas de privacidade. Não colocar chaves de fornecedor no navegador.

## Protecção e privacidade
- Endpoints protegidos por JWT.
- Professor só gere as próprias sessões.
- Estudante precisa de inscrição activa no curso.
- Não há gravação automática.
- Não expor links de reunião públicos; a autorização é verificada no servidor.
- Em produção, acrescentar limites de participantes, auditoria de início/fim, política de retenção e validação de conflitos de horário.

## Endpoints
- `POST /api/live/sessions` — professor agenda sessão.
- `GET /api/live/sessions/mine` — lista sessões acessíveis à conta.
- `POST /api/live/sessions/{id}/join` — valida acesso e regista entrada.
- `POST /api/live/sessions/{id}/start` — professor inicia sessão.
- `POST /api/live/sessions/{id}/end` — professor termina sessão ao vivo.
- `POST /api/live/sessions/{id}/cancel` — professor cancela sessão.

## Corpo para agendar
```json
{
  "courseId": 12,
  "title": "Aula de revisão",
  "description": "Resolução de exercícios",
  "startsAt": "2026-11-10T14:00:00",
  "endsAt": "2026-11-10T15:00:00"
}
```

As datas são interpretadas no fuso configurado pela aplicação (`Africa/Luanda`).

## Testes manuais necessários
1. Aplicar a migração V6 numa base de dados de teste.
2. Autenticar como professor com curso APPROVED e agendar uma sessão.
3. Tentar agendar para curso de outro professor: deve responder 403.
4. Autenticar como estudante sem inscrição ACTIVE e tentar entrar: deve responder 403.
5. Estudante com inscrição ACTIVE entra; a participação fica registada.
6. Professor inicia e termina a sua sessão.
7. Outra conta de professor tenta gerir a sessão: deve falhar.
8. Confirmar que sessão cancelada/terminada não aceita novas entradas.

## Estado de validação
Estrutura Java, SQL, HTML e JavaScript foram adicionados ao projecto. A compilação Maven e os testes de integração com MySQL ainda precisam de ser executados no ambiente de desenvolvimento.
