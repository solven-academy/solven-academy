# SOLVEN Academy — Etapa 19: SOLVEN LIVE

Esta versão acrescenta o agendamento e a gestão de salas de aulas ao vivo, com controlo de acesso para professores e estudantes.

**Atenção:** a Etapa 19 ainda não inclui transmissão real de áudio/vídeo. A integração WebRTC/SFU será uma fase técnica própria, após seleccionar e configurar o serviço de media.

Começa por ler `docs/ETAPA19-SOLVEN-LIVE.md` e `RECOMECA_AQUI.txt`. Mantém as configurações e migrações anteriores. Testa primeiro numa base de dados de desenvolvimento e faz backup antes de actualizar uma instalação existente.
