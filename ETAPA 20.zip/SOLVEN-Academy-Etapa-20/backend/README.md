# SOLVEN API — Etapa 19

Backend Spring Boot 3.5 / Java 21. A Etapa 19 acrescenta o agendamento e controlo de aulas ao vivo. Consulta `../docs/ETAPA19-SOLVEN-LIVE.md` e `../RECOMECA_AQUI.txt`.

Executar em desenvolvimento: `mvn spring-boot:run` (com MySQL 8, JDK 21, Maven e variáveis de ambiente configurados). Interface: `http://localhost:8080/`.

A aplicação utiliza Flyway para as migrações V1 a V6. Faz backup antes de actualizar uma base de dados existente. Esta etapa ainda não transmite áudio/vídeo; a sala informa `mediaStatus=NOT_CONFIGURED`.

Não publicar em produção sem HTTPS, gestão segura de segredos, testes automatizados/de segurança, backups, monitorização e revisão independente.
