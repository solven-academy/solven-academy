const API = '';
const $ = (id) => document.getElementById(id);
let mode = 'login';
$('year').textContent = new Date().getFullYear();

function showMessage(text, good=false) {
  $('message').textContent = text;
  $('message').style.color = good ? '#087e70' : '#b42318';
}
function setMode(next) {
  mode = next;
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  $('nameWrap').classList.toggle('hidden', mode !== 'register');
  $('roleWrap').classList.toggle('hidden', mode !== 'register');
  $('fullName').required = mode === 'register';
  $('password').autocomplete = mode === 'register' ? 'new-password' : 'current-password';
  $('submitBtn').textContent = mode === 'register' ? 'Criar a minha conta' : 'Entrar na SOLVEN';
  showMessage('');
}
document.querySelectorAll('.tab').forEach(b => b.addEventListener('click', () => setMode(b.dataset.mode)));

async function request(path, options={}) {
  const response = await fetch(API + path, {
    ...options,
    headers: {'Content-Type':'application/json', ...(options.headers || {})}
  });
  const raw = await response.text();
  let data = {};
  try { data = raw ? JSON.parse(raw) : {}; } catch { data = {message: raw}; }
  if (!response.ok) throw new Error(data.detail || data.message || `Erro ${response.status}. Verifica os dados e tenta novamente.`);
  return data;
}

$('authForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = $('submitBtn');
  button.disabled = true;
  showMessage('A comunicar com o servidor SOLVEN…', true);
  const body = {email:$('email').value.trim(), password:$('password').value};
  if (mode === 'register') {
    body.fullName = $('fullName').value.trim();
    body.role = $('role').value;
  }
  try {
    const result = await request(mode === 'register' ? '/api/auth/register' : '/api/auth/login', {
      method:'POST', body:JSON.stringify(body)
    });
    // Token guardado apenas na sessão deste separador; termina quando a sessão do separador termina.
    sessionStorage.setItem('solven_access_token', result.accessToken);
    await loadDashboard(result.user);
  } catch (error) {
    showMessage(error.message || 'Não foi possível contactar o servidor.');
  } finally { button.disabled = false; }
});

async function loadDashboard(userFromAuth) {
  const token = sessionStorage.getItem('solven_access_token');
  if (!token) return;
  try {
    const user = await request('/api/me', {headers:{Authorization:`Bearer ${token}`}});
    $('userName').textContent = user.fullName || userFromAuth?.fullName || 'utilizador';
    $('profileName').textContent = user.fullName || '';
    $('profileEmail').textContent = user.email || '';
    $('profileRole').textContent = user.role === 'TEACHER' ? 'PROFESSOR' : 'ESTUDANTE';
    if (user.role === 'TEACHER') { $('teacherTools').classList.remove('hidden'); $('studentCatalog').classList.add('hidden'); $('liveForm').classList.remove('hidden'); await loadTeacherCourses(); await loadLiveSessions(user.role); }
    else { $('studentCatalog').classList.remove('hidden'); $('teacherTools').classList.add('hidden'); $('liveForm').classList.add('hidden'); await loadPublicCourses(); await loadLiveSessions(user.role); }
    $('avatar').textContent = (user.fullName || 'S').trim().charAt(0).toUpperCase();
    $('authCard').classList.add('hidden');
    $('dashboard').classList.remove('hidden');
  } catch (error) {
    sessionStorage.removeItem('solven_access_token');
    showMessage('A sessão expirou ou não é válida. Entra novamente.');
  }
}
$('logoutBtn').addEventListener('click', () => {
  sessionStorage.removeItem('solven_access_token');
  $('dashboard').classList.add('hidden');
  $('authCard').classList.remove('hidden');
  $('authForm').reset();
  setMode('login');
  showMessage('Sessão terminada com sucesso.', true);
});

(async function restoreSession(){
  if (sessionStorage.getItem('solven_access_token')) await loadDashboard();
})();


async function apiWithToken(path, options={}) {
  const token = sessionStorage.getItem('solven_access_token');
  return request(path, {...options, headers:{...(options.headers||{}), Authorization:`Bearer ${token}`}});
}
function renderCourseList(target, courses, own=false) {
  const box=$(target); box.replaceChildren();
  if (!courses.length) { const p=document.createElement('p'); p.className='muted'; p.textContent=own?'Ainda não publicaste cursos.':'Ainda não existem cursos aprovados.'; box.append(p); return; }
  courses.forEach(course=>{
    const card=document.createElement('article'); card.className='course-item';
    const title=document.createElement('strong'); title.textContent=course.title;
    const meta=document.createElement('p'); meta.textContent=`${course.categoryName} · ${course.level} · ${Number(course.priceAoa).toLocaleString('pt-AO')} Kz`;
    const desc=document.createElement('p'); desc.textContent=course.description;
    const status=document.createElement('span'); status.className='role-pill'; status.textContent=course.status;
    card.append(title,meta,desc,status); box.append(card);
  });
}
async function loadTeacherCourses() {
  try {
    const [categories,courses]=await Promise.all([apiWithToken('/api/categories'),apiWithToken('/api/teacher/courses')]);
    const select=$('courseCategory'); select.replaceChildren();
    categories.forEach(c=>{const option=document.createElement('option');option.value=c.id;option.textContent=c.name;select.append(option);});
    renderCourseList('myCourses',courses,true); await refreshLiveCourseOptions();
  } catch(e) { $('courseMessage').textContent=e.message; }
}
async function loadPublicCourses() {
  try { const courses=await request('/api/courses'); renderCourseList('publicCourses',courses,false); }
  catch(e) { $('publicCourses').textContent='Não foi possível carregar o catálogo.'; }
}
$('courseForm')?.addEventListener('submit', async event=>{
  event.preventDefault(); const button=$('courseSubmit'); button.disabled=true; $('courseMessage').textContent='A enviar…';
  const payload={title:$('courseTitle').value.trim(),description:$('courseDescription').value.trim(),categoryId:Number($('courseCategory').value),level:$('courseLevel').value,priceAoa:Number($('coursePrice').value)};
  try { await apiWithToken('/api/teacher/courses',{method:'POST',body:JSON.stringify(payload)}); $('courseForm').reset(); $('courseMessage').textContent='Curso enviado. Estado: PENDING (aguarda análise).'; await loadTeacherCourses(); }
  catch(e) { $('courseMessage').textContent=e.message; }
  finally { button.disabled=false; }
});


// Etapa 19 — SOLVEN LIVE: agenda e entrada autorizada nas salas.
async function loadLiveSessions(role) {
  const box = $('liveSessions');
  try {
    const sessions = await apiWithToken('/api/live/sessions/mine');
    box.replaceChildren();
    if (!sessions.length) { const p=document.createElement('p'); p.className='muted'; p.textContent='Ainda não há aulas ao vivo disponíveis nesta conta.'; box.append(p); }
    sessions.forEach(session => {
      const card=document.createElement('article'); card.className='course-item';
      const title=document.createElement('strong'); title.textContent=session.title;
      const meta=document.createElement('p'); meta.textContent=`${session.courseTitle} · ${new Date(session.startsAt).toLocaleString('pt-AO')} · ${session.status} · ${session.participantCount} participante(s)`;
      const teacher=document.createElement('p'); teacher.textContent=`Professor: ${session.teacherName}`;
      card.append(title,meta,teacher);
      if (session.status==='SCHEDULED' || session.status==='LIVE') {
        const join=document.createElement('button'); join.className='secondary'; join.type='button'; join.textContent='Entrar na sala';
        join.addEventListener('click', async()=>{
          try { const room=await apiWithToken(`/api/live/sessions/${session.id}/join`,{method:'POST'}); const info=$('liveRoomInfo'); info.classList.remove('hidden'); info.textContent=`Sala ${room.title} · Código ${room.roomCode}. ${room.message}`; }
          catch(e){ $('liveMessage').textContent=e.message; }
        }); card.append(join);
        if (role==='TEACHER') {
          const start=document.createElement('button'); start.className='secondary'; start.type='button'; start.textContent='Iniciar aula'; start.addEventListener('click',async()=>{try{await apiWithToken(`/api/live/sessions/${session.id}/start`,{method:'POST'});await loadLiveSessions(role);}catch(e){$('liveMessage').textContent=e.message;}}); card.append(start);
          if(session.status==='LIVE'){const end=document.createElement('button');end.className='secondary';end.type='button';end.textContent='Terminar aula';end.addEventListener('click',async()=>{try{await apiWithToken(`/api/live/sessions/${session.id}/end`,{method:'POST'});await loadLiveSessions(role);}catch(e){$('liveMessage').textContent=e.message;}});card.append(end);}
        }
      }
      box.append(card);
    });
  } catch(e) { box.textContent=e.message; }
}

async function refreshLiveCourseOptions() {
  const select=$('liveCourse'); if(!select) return;
  try {
    const courses=await apiWithToken('/api/teacher/courses');
    select.replaceChildren();
    courses.filter(c=>c.status==='APPROVED').forEach(c=>{const o=document.createElement('option');o.value=c.id;o.textContent=c.title;select.append(o);});
    if(!select.options.length){const o=document.createElement('option');o.value='';o.textContent='Precisas de ter um curso aprovado';select.append(o);$('liveSubmit').disabled=true;}
  } catch(e){$('liveMessage').textContent=e.message;}
}
$('liveForm')?.addEventListener('submit',async event=>{
  event.preventDefault(); const button=$('liveSubmit');button.disabled=true;$('liveMessage').textContent='A agendar…';
  const payload={courseId:Number($('liveCourse').value),title:$('liveTitle').value.trim(),description:$('liveDescription').value.trim(),startsAt:$('liveStarts').value,endsAt:$('liveEnds').value};
  try{await apiWithToken('/api/live/sessions',{method:'POST',body:JSON.stringify(payload)});$('liveForm').reset();$('liveMessage').textContent='Aula agendada com sucesso.';await loadLiveSessions('TEACHER');}
  catch(e){$('liveMessage').textContent=e.message;}finally{button.disabled=false;}
});
