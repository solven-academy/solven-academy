-- Etapa 20: metadados dos vídeos e materiais; binários ficam fora da pasta pública.
CREATE TABLE media_assets (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  course_id BIGINT UNSIGNED NOT NULL,
  uploaded_by BIGINT UNSIGNED NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  storage_key VARCHAR(80) NOT NULL UNIQUE,
  content_type VARCHAR(120) NOT NULL,
  file_size BIGINT UNSIGNED NOT NULL,
  media_type ENUM('VIDEO','DOCUMENT','IMAGE') NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_media_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  CONSTRAINT fk_media_uploader FOREIGN KEY (uploaded_by) REFERENCES users(id),
  INDEX idx_media_course_created (course_id, created_at)
) ENGINE=InnoDB;
