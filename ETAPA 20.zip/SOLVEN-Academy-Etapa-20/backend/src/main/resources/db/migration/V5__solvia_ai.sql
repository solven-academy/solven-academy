-- Etapa 18: histórico privado de conversas SOLVIA. Não armazena chaves do fornecedor.
CREATE TABLE solvia_conversations (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(160) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_solvia_conversation_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_solvia_user_updated (user_id,updated_at)
) ENGINE=InnoDB;
CREATE TABLE solvia_messages (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 conversation_id BIGINT UNSIGNED NOT NULL,
 role VARCHAR(16) NOT NULL,
 content TEXT NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_solvia_message_conversation FOREIGN KEY (conversation_id) REFERENCES solvia_conversations(id) ON DELETE CASCADE,
 CONSTRAINT chk_solvia_message_role CHECK (role IN ('user','assistant')),
 INDEX idx_solvia_message_history (conversation_id,id)
) ENGINE=InnoDB;
