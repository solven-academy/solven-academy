-- SOLVEN PROTECT: registo de reclamações, declarações, evidências e decisões.
-- Esta migração NÃO movimenta, bloqueia nem reembolsa dinheiro.
CREATE TABLE protection_cases (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 enrollment_id BIGINT UNSIGNED NOT NULL,
 student_id BIGINT UNSIGNED NOT NULL,
 teacher_id BIGINT UNSIGNED NOT NULL,
 claim_type VARCHAR(50) NOT NULL,
 description VARCHAR(2000) NOT NULL,
 requested_resolution VARCHAR(500) NULL,
 status VARCHAR(32) NOT NULL DEFAULT 'OPEN',
 student_statement VARCHAR(3000) NULL,
 teacher_statement VARCHAR(3000) NULL,
 admin_decision VARCHAR(3000) NULL,
 financial_action VARCHAR(40) NOT NULL DEFAULT 'NONE',
 reviewed_by BIGINT UNSIGNED NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_case_enrollment FOREIGN KEY (enrollment_id) REFERENCES enrollments(id),
 CONSTRAINT fk_case_student FOREIGN KEY (student_id) REFERENCES users(id),
 CONSTRAINT fk_case_teacher FOREIGN KEY (teacher_id) REFERENCES users(id),
 CONSTRAINT fk_case_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id),
 CONSTRAINT chk_case_status CHECK (status IN ('OPEN','UNDER_REVIEW','WAITING_FOR_STUDENT','WAITING_FOR_TEACHER','RESOLVED_STUDENT','RESOLVED_TEACHER','CLOSED')),
 INDEX idx_case_student (student_id,created_at),
 INDEX idx_case_teacher (teacher_id,created_at),
 INDEX idx_case_status (status,created_at)
) ENGINE=InnoDB;
CREATE TABLE protection_evidence (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 case_id BIGINT UNSIGNED NOT NULL,
 submitted_by BIGINT UNSIGNED NOT NULL,
 description VARCHAR(1200) NOT NULL,
 storage_reference VARCHAR(500) NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (case_id) REFERENCES protection_cases(id) ON DELETE CASCADE,
 FOREIGN KEY (submitted_by) REFERENCES users(id),
 INDEX idx_evidence_case (case_id,created_at)
) ENGINE=InnoDB;
