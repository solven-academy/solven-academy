-- SOLVEN Academy | esquema inicial MySQL 8
-- Executar numa base de dados vazia chamada solven_academy.
-- Não contém utilizadores reais nem palavras-passe.


CREATE TABLE users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(254) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'STUDENT',
  account_status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  email_verified_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_user_role CHECK (role IN ('STUDENT','TEACHER','ADMIN')),
  CONSTRAINT chk_user_status CHECK (account_status IN ('ACTIVE','SUSPENDED','PENDING')),
  INDEX idx_users_role_status (role, account_status)
) ENGINE=InnoDB;

CREATE TABLE student_profiles (
  user_id BIGINT UNSIGNED PRIMARY KEY,
  country VARCHAR(80) NULL,
  city VARCHAR(100) NULL,
  biography VARCHAR(500) NULL,
  learning_level ENUM('BEGINNER','INTERMEDIATE','ADVANCED') NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE teacher_profiles (
  user_id BIGINT UNSIGNED PRIMARY KEY,
  country VARCHAR(80) NULL,
  city VARCHAR(100) NULL,
  biography VARCHAR(1000) NULL,
  specialty VARCHAR(150) NULL,
  qualifications TEXT NULL,
  experience_years SMALLINT UNSIGNED NULL,
  verification_status ENUM('UNVERIFIED','PENDING','VERIFIED','REJECTED') NOT NULL DEFAULT 'UNVERIFIED',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE categories (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  slug VARCHAR(120) NOT NULL UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE courses (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  teacher_id BIGINT UNSIGNED NOT NULL,
  category_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(180) NOT NULL,
  description TEXT NOT NULL,
  level ENUM('BEGINNER','INTERMEDIATE','ADVANCED') NOT NULL,
  price_aoa DECIMAL(12,2) NOT NULL DEFAULT 0,
  status ENUM('DRAFT','PENDING','APPROVED','REJECTED','ARCHIVED') NOT NULL DEFAULT 'DRAFT',
  rejection_reason VARCHAR(500) NULL,
  reviewed_by BIGINT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_course_price CHECK (price_aoa >= 0),
  FOREIGN KEY (teacher_id) REFERENCES users(id),
  FOREIGN KEY (category_id) REFERENCES categories(id),
  FOREIGN KEY (reviewed_by) REFERENCES users(id),
  INDEX idx_courses_status_category (status, category_id),
  INDEX idx_courses_teacher (teacher_id)
) ENGINE=InnoDB;

CREATE TABLE lessons (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  course_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(180) NOT NULL,
  description TEXT NULL,
  position INT UNSIGNED NOT NULL,
  media_object_key VARCHAR(500) NULL,
  duration_seconds INT UNSIGNED NULL,
  is_preview BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_course_lesson_position (course_id, position),
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE enrollments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id BIGINT UNSIGNED NOT NULL,
  course_id BIGINT UNSIGNED NOT NULL,
  enrollment_status ENUM('PENDING','ACTIVE','CANCELLED','COMPLETED') NOT NULL DEFAULT 'PENDING',
  enrolled_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_student_course (student_id, course_id),
  FOREIGN KEY (student_id) REFERENCES users(id),
  FOREIGN KEY (course_id) REFERENCES courses(id),
  INDEX idx_enrollments_student_status (student_id, enrollment_status)
) ENGINE=InnoDB;

CREATE TABLE payments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  enrollment_id BIGINT UNSIGNED NOT NULL,
  provider VARCHAR(80) NOT NULL,
  provider_reference VARCHAR(180) NOT NULL,
  amount_aoa DECIMAL(12,2) NOT NULL,
  payment_status ENUM('CREATED','PENDING','PAID','FAILED','REFUNDED') NOT NULL DEFAULT 'CREATED',
  paid_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_provider_reference (provider, provider_reference),
  FOREIGN KEY (enrollment_id) REFERENCES enrollments(id),
  CONSTRAINT chk_payment_amount CHECK (amount_aoa >= 0)
) ENGINE=InnoDB;

CREATE TABLE reviews (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  enrollment_id BIGINT UNSIGNED NOT NULL UNIQUE,
  rating TINYINT UNSIGNED NOT NULL,
  comment VARCHAR(1000) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
  FOREIGN KEY (enrollment_id) REFERENCES enrollments(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_user_id BIGINT UNSIGNED NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  entity_id BIGINT UNSIGNED NULL,
  details JSON NULL,
  ip_address VARBINARY(16) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (actor_user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_audit_actor_date (actor_user_id, created_at)
) ENGINE=InnoDB;

-- Categorias iniciais de demonstração
INSERT INTO categories (name, slug) VALUES
('Matemática','matematica'),('Física','fisica'),('Programação','programacao'),
('Hacker Ético','hacker-etico'),('Design e Multimédia','design-multimedia'),
('Redes e Cibersegurança','redes-ciberseguranca');
