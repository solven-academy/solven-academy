-- SOLVEN Academy | Etapa 16: fundação financeira internacional
-- Esta migração prepara dados multi-moeda. NÃO activa cobranças reais.
-- Executar apenas através do Flyway numa instalação MySQL 8 compatível.

ALTER TABLE courses
  ADD COLUMN price_currency CHAR(3) NOT NULL DEFAULT 'AOA' AFTER price_aoa;

ALTER TABLE payments
  ADD COLUMN amount DECIMAL(19,4) NULL AFTER provider_reference,
  ADD COLUMN currency CHAR(3) NOT NULL DEFAULT 'AOA' AFTER amount,
  ADD COLUMN settlement_amount_aoa DECIMAL(19,4) NULL AFTER currency,
  ADD COLUMN fx_rate_to_aoa DECIMAL(20,10) NULL AFTER settlement_amount_aoa,
  ADD COLUMN idempotency_key VARCHAR(100) NULL AFTER fx_rate_to_aoa,
  ADD COLUMN provider_checkout_reference VARCHAR(180) NULL AFTER idempotency_key,
  ADD COLUMN failure_code VARCHAR(100) NULL AFTER provider_checkout_reference,
  ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

CREATE UNIQUE INDEX uq_payment_idempotency ON payments(idempotency_key);
CREATE INDEX idx_payments_currency_status ON payments(currency, payment_status, created_at);

CREATE TABLE payment_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  payment_id BIGINT UNSIGNED NOT NULL,
  provider_event_id VARCHAR(180) NOT NULL,
  event_type VARCHAR(100) NOT NULL,
  signature_verified BOOLEAN NOT NULL DEFAULT FALSE,
  payload_hash CHAR(64) NOT NULL,
  processed_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_provider_event (provider_event_id),
  FOREIGN KEY (payment_id) REFERENCES payments(id),
  INDEX idx_payment_events_payment (payment_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE teacher_wallet_entries (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  teacher_id BIGINT UNSIGNED NOT NULL,
  payment_id BIGINT UNSIGNED NULL,
  entry_type ENUM('SALE_CREDIT','PLATFORM_FEE','REFUND_DEBIT','PAYOUT_DEBIT','ADJUSTMENT') NOT NULL,
  amount DECIMAL(19,4) NOT NULL,
  currency CHAR(3) NOT NULL,
  entry_status ENUM('PENDING','AVAILABLE','REVERSED','PAID_OUT') NOT NULL DEFAULT 'PENDING',
  description VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (teacher_id) REFERENCES users(id),
  FOREIGN KEY (payment_id) REFERENCES payments(id),
  INDEX idx_wallet_teacher_status (teacher_id, entry_status, created_at)
) ENGINE=InnoDB;

CREATE TABLE supported_currencies (
  currency_code CHAR(3) PRIMARY KEY,
  currency_name VARCHAR(80) NOT NULL,
  minor_units TINYINT UNSIGNED NOT NULL,
  is_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO supported_currencies (currency_code, currency_name, minor_units, is_enabled) VALUES
('AOA','Kwanza angolano',2,TRUE),
('USD','Dólar dos Estados Unidos',2,FALSE),
('EUR','Euro',2,FALSE),
('BRL','Real brasileiro',2,FALSE),
('GBP','Libra esterlina',2,FALSE),
('ZAR','Rand sul-africano',2,FALSE),
('CAD','Dólar canadiano',2,FALSE),
('CHF','Franco suíço',2,FALSE),
('MZN','Metical moçambicano',2,FALSE),
('NAD','Dólar namibiano',2,FALSE);

-- Nota: os valores antigos permanecem em AOA. A activação de outras moedas
-- exige fornecedor de pagamento contratado, taxas verificadas e testes por país.
