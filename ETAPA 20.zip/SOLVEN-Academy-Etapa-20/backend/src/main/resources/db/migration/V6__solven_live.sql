-- Etapa 19: agendamento e controlo de salas de aulas ao vivo.
CREATE TABLE live_sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  course_id BIGINT UNSIGNED NOT NULL,
  teacher_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(180) NOT NULL,
  description VARCHAR(1000) NULL,
  starts_at DATETIME NOT NULL,
  ends_at DATETIME NOT NULL,
  room_code VARCHAR(64) NOT NULL UNIQUE,
  session_status ENUM('SCHEDULED','LIVE','ENDED','CANCELLED') NOT NULL DEFAULT 'SCHEDULED',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_live_session_time CHECK (ends_at > starts_at),
  FOREIGN KEY (course_id) REFERENCES courses(id),
  FOREIGN KEY (teacher_id) REFERENCES users(id),
  INDEX idx_live_teacher_start (teacher_id, starts_at),
  INDEX idx_live_course_start (course_id, starts_at)
) ENGINE=InnoDB;

CREATE TABLE live_session_participants (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  left_at DATETIME NULL,
  UNIQUE KEY uq_live_session_user (session_id, user_id),
  FOREIGN KEY (session_id) REFERENCES live_sessions(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_live_participant_user (user_id, joined_at)
) ENGINE=InnoDB;
