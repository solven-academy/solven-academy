-- SOLVEN Academy | Etapa 15: inscrições e matrículas
-- A tabela já existia no schema inicial; esta migração torna explícitas
-- as garantias usadas pela API e adiciona um índice de consulta por curso.
CREATE INDEX idx_enrollments_course_status ON enrollments(course_id, enrollment_status);
