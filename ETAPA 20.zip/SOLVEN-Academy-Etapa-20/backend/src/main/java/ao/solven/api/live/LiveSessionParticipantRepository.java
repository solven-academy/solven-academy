package ao.solven.api.live;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface LiveSessionParticipantRepository extends JpaRepository<LiveSessionParticipant,Long> {
 Optional<LiveSessionParticipant> findBySessionIdAndUserEmail(Long sessionId,String email);
 long countBySessionId(Long sessionId);
}
