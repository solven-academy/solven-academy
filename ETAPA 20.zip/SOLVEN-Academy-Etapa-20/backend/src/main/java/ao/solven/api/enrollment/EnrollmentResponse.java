package ao.solven.api.enrollment;
import java.math.BigDecimal;
import java.time.LocalDateTime;
public record EnrollmentResponse(Long enrollmentId, Long courseId, String courseTitle, String teacherName,
        BigDecimal priceAoa, String status, LocalDateTime enrolledAt, String nextStep) {
    static EnrollmentResponse from(Enrollment e) {
        String next = e.getStatus() == EnrollmentStatus.PENDING
            ? "A inscrição aguarda confirmação do pagamento. O acesso ao curso ainda não foi libertado."
            : e.getStatus() == EnrollmentStatus.ACTIVE ? "Inscrição activa. O estudante pode aceder ao curso." : "Consulte o estado da inscrição.";
        return new EnrollmentResponse(e.getId(), e.getCourse().getId(), e.getCourse().getTitle(),
            e.getCourse().getTeacher().getFullName(), e.getCourse().getPriceAoa(), e.getStatus().name(), e.getEnrolledAt(), next);
    }
}
