package ao.solven.api.live;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface LiveSessionRepository extends JpaRepository<LiveSession,Long> {
 List<LiveSession> findByTeacherEmailOrderByStartsAtDesc(String email);
 List<LiveSession> findByCourseIdOrderByStartsAtAsc(Long courseId);
 Optional<LiveSession> findByIdAndTeacherEmail(Long id,String email);
}
