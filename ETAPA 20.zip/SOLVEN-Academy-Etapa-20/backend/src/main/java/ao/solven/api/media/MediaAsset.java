package ao.solven.api.media;

import ao.solven.api.course.Course;
import ao.solven.api.user.UserAccount;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "media_assets")
public class MediaAsset {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "course_id", nullable = false)
    private Course course;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "uploaded_by", nullable = false)
    private UserAccount uploadedBy;
    @Column(name = "original_name", nullable = false, length = 255) private String originalName;
    @Column(name = "storage_key", nullable = false, unique = true, length = 80) private String storageKey;
    @Column(name = "content_type", nullable = false, length = 120) private String contentType;
    @Column(name = "file_size", nullable = false) private long fileSize;
    @Enumerated(EnumType.STRING) @Column(name = "media_type", nullable = false, length = 20) private MediaType mediaType;
    @Column(name = "created_at", insertable = false, updatable = false) private LocalDateTime createdAt;
    protected MediaAsset() {}
    public MediaAsset(Course course, UserAccount uploadedBy, String originalName, String storageKey, String contentType, long fileSize, MediaType mediaType) {
        this.course=course; this.uploadedBy=uploadedBy; this.originalName=originalName; this.storageKey=storageKey; this.contentType=contentType; this.fileSize=fileSize; this.mediaType=mediaType;
    }
    public Long getId(){return id;} public Course getCourse(){return course;} public UserAccount getUploadedBy(){return uploadedBy;}
    public String getOriginalName(){return originalName;} public String getStorageKey(){return storageKey;} public String getContentType(){return contentType;}
    public long getFileSize(){return fileSize;} public MediaType getMediaType(){return mediaType;} public LocalDateTime getCreatedAt(){return createdAt;}
}
