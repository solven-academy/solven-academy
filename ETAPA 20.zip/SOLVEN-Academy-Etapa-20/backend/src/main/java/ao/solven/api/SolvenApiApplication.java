package ao.solven.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolvenApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(SolvenApiApplication.class, args);
    }
}
