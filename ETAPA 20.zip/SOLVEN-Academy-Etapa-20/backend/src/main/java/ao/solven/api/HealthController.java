package ao.solven.api;

import java.time.Instant;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthController {
    private final JdbcTemplate jdbcTemplate;

    public HealthController(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping("/api/health")
    public Map<String, Object> health() {
        // A resposta confirma que a API consegue consultar a base de dados.
        Integer result = jdbcTemplate.queryForObject("SELECT 1", Integer.class);
        return Map.of(
            "application", "SOLVEN Academy API",
            "status", "UP",
            "database", result != null && result == 1 ? "UP" : "UNKNOWN",
            "timestamp", Instant.now().toString()
        );
    }
}
