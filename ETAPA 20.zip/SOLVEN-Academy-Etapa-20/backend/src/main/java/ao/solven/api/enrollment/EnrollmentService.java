package ao.solven.api.enrollment;

import ao.solven.api.course.*;
import ao.solven.api.user.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.util.List;

@Service
public class EnrollmentService {
    private final EnrollmentRepository enrollments;
    private final CourseRepository courses;
    private final UserAccountRepository users;
    public EnrollmentService(EnrollmentRepository enrollments, CourseRepository courses, UserAccountRepository users) {
        this.enrollments = enrollments; this.courses = courses; this.users = users;
    }
    @Transactional
    public EnrollmentResponse enroll(String email, Long courseId) {
        UserAccount student = users.findByEmail(email).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
        if (student.getRole() != AccountRole.STUDENT) throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Apenas estudantes podem inscrever-se.");
        Course course = courses.findById(courseId).filter(c -> c.getStatus() == CourseStatus.APPROVED)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Curso aprovado não encontrado."));
        if (enrollments.findByStudentEmailAndCourseId(email, courseId).isPresent())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Já existe uma inscrição neste curso.");
        EnrollmentStatus status = course.getPriceAoa().compareTo(BigDecimal.ZERO) == 0 ? EnrollmentStatus.ACTIVE : EnrollmentStatus.PENDING;
        return EnrollmentResponse.from(enrollments.save(new Enrollment(student, course, status)));
    }
    @Transactional(readOnly = true)
    public List<EnrollmentResponse> mine(String email) {
        return enrollments.findByStudentEmailOrderByEnrolledAtDesc(email).stream().map(EnrollmentResponse::from).toList();
    }
    @Transactional(readOnly = true)
    public List<StudentEnrollmentView> studentsForTeacher(String email, Long courseId) {
        Course course = courses.findById(courseId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Curso não encontrado."));
        if (!course.getTeacher().getEmail().equals(email)) throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Só podes consultar estudantes dos teus próprios cursos.");
        return enrollments.findByCourseIdOrderByEnrolledAtDesc(courseId).stream()
            .map(e -> new StudentEnrollmentView(e.getStudent().getFullName(), e.getStudent().getEmail(), e.getStatus().name(), e.getEnrolledAt())).toList();
    }
    public record StudentEnrollmentView(String studentName, String studentEmail, String status, java.time.LocalDateTime enrolledAt) {}
}
