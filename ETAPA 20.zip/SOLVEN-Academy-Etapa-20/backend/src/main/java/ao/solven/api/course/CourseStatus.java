package ao.solven.api.course;
public enum CourseStatus { DRAFT, PENDING, APPROVED, REJECTED, ARCHIVED }
