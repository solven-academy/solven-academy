package ao.solven.api.protect;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ProtectionEvidenceRepository extends JpaRepository<ProtectionEvidence,Long>{List<ProtectionEvidence> findByProtectionCaseIdOrderByCreatedAtAsc(Long caseId);}
