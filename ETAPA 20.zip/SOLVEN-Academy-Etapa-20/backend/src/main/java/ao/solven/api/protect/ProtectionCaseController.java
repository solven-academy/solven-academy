package ao.solven.api.protect;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api")
public class ProtectionCaseController {
 private final ProtectionCaseService service;
 public ProtectionCaseController(ProtectionCaseService service){this.service=service;}
 @PostMapping("/student/protection-cases") @ResponseStatus(HttpStatus.CREATED)
 public ProtectionCaseService.CaseView open(@Valid @RequestBody ProtectionCaseService.OpenCaseRequest r,Authentication a){return service.open(a.getName(),r);}
 @GetMapping("/protection-cases/mine") public List<ProtectionCaseService.CaseView> mine(Authentication a){return service.mine(a.getName());}
 @PostMapping("/protection-cases/{id}/statement") public ProtectionCaseService.CaseView statement(@PathVariable Long id,@Valid @RequestBody ProtectionCaseService.StatementRequest r,Authentication a){return service.statement(id,a.getName(),r.statement());}
 @PostMapping("/protection-cases/{id}/evidence") @ResponseStatus(HttpStatus.CREATED) public ProtectionCaseService.EvidenceView evidence(@PathVariable Long id,@Valid @RequestBody ProtectionCaseService.EvidenceRequest r,Authentication a){return service.addEvidence(id,a.getName(),r);}
 @GetMapping("/protection-cases/{id}/evidence") public List<ProtectionCaseService.EvidenceView> evidenceList(@PathVariable Long id,Authentication a){return service.evidence(id,a.getName());}
 @GetMapping("/admin/protection-cases") public List<ProtectionCaseService.CaseView> all(){return service.all();}
 @PatchMapping("/admin/protection-cases/{id}/review") public ProtectionCaseService.CaseView review(@PathVariable Long id,@Valid @RequestBody ProtectionCaseService.ReviewCaseRequest r,Authentication a){return service.adminReview(id,a.getName(),r);}
}
