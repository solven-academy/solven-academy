package ao.solven.api.live;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/live/sessions")
public class LiveSessionController {
 private final LiveSessionService service; public LiveSessionController(LiveSessionService service){this.service=service;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public LiveSessionService.SessionView create(@Valid @RequestBody LiveSessionService.CreateRequest body,Authentication auth){return service.create(auth.getName(),body);}
 @GetMapping("/mine") public List<LiveSessionService.SessionView> mine(Authentication auth){return service.mine(auth.getName());}
 @PostMapping("/{id}/join") public LiveSessionService.RoomView join(@PathVariable Long id,Authentication auth){return service.join(auth.getName(),id);}
 @PostMapping("/{id}/start") public LiveSessionService.SessionView start(@PathVariable Long id,Authentication auth){return service.changeStatus(auth.getName(),id,LiveSessionStatus.LIVE);}
 @PostMapping("/{id}/end") public LiveSessionService.SessionView end(@PathVariable Long id,Authentication auth){return service.changeStatus(auth.getName(),id,LiveSessionStatus.ENDED);}
 @PostMapping("/{id}/cancel") public LiveSessionService.SessionView cancel(@PathVariable Long id,Authentication auth){return service.changeStatus(auth.getName(),id,LiveSessionStatus.CANCELLED);}
}
