package ao.solven.api.course;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api")
public class CourseController {
 private final CourseService service;
 public CourseController(CourseService service){this.service=service;}
 @GetMapping("/categories") public List<CategoryResponse> categories(){return service.categories().stream().map(c->new CategoryResponse(c.getId(),c.getName(),c.getSlug())).toList();}
 @GetMapping("/courses") public List<CourseResponse> courses(@RequestParam(required=false) Long categoryId){return service.publicCourses(categoryId);}
 @GetMapping("/courses/{id}") public CourseResponse course(@PathVariable Long id){return service.publicCourse(id);}
 @PostMapping("/teacher/courses") @ResponseStatus(HttpStatus.CREATED) public CourseResponse create(@Valid @RequestBody CreateCourseRequest request, Authentication auth){return service.create(auth.getName(),request);}
 @GetMapping("/teacher/courses") public List<CourseResponse> mine(Authentication auth){return service.mine(auth.getName());}
 public record CategoryResponse(Long id,String name,String slug){}
}
