package ao.solven.api.course;
import java.math.BigDecimal;
import java.time.LocalDateTime;
public record CourseResponse(Long id, String title, String description, String level, BigDecimal priceAoa, String status, Long categoryId, String categoryName, String teacherName, LocalDateTime createdAt) {
 static CourseResponse from(Course c){return new CourseResponse(c.getId(),c.getTitle(),c.getDescription(),c.getLevel().name(),c.getPriceAoa(),c.getStatus().name(),c.getCategory().getId(),c.getCategory().getName(),c.getTeacher().getFullName(),c.getCreatedAt());}
}
