package ao.solven.api.user;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface UserAccountRepository extends JpaRepository<UserAccount, Long> {
    Optional<UserAccount> findByEmail(String email);
    boolean existsByEmail(String email);
 java.util.List<UserAccount> findAllByOrderByCreatedAtDesc();
 long countByRole(AccountRole role);
 long countByAccountStatus(AccountStatus status);
 long countByRoleAndAccountStatus(AccountRole role, AccountStatus status);
}
