package ao.solven.api.user;
public enum AccountRole { STUDENT, TEACHER, ADMIN }
