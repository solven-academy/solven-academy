package ao.solven.api.config;
import ao.solven.api.auth.JwtService;
import ao.solven.api.user.UserAccountRepository;
import jakarta.servlet.*; import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component; import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException; import java.util.List;
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
 private final JwtService jwt; private final UserAccountRepository users;
 public JwtAuthenticationFilter(JwtService jwt,UserAccountRepository users){this.jwt=jwt;this.users=users;}
 @Override protected void doFilterInternal(HttpServletRequest request,HttpServletResponse response,FilterChain chain) throws ServletException,IOException {
  String header=request.getHeader("Authorization");
  if(header!=null && header.startsWith("Bearer ") && SecurityContextHolder.getContext().getAuthentication()==null){
   try {String email=jwt.extractSubject(header.substring(7)); users.findByEmail(email).filter(u->u.getAccountStatus().name().equals("ACTIVE")).ifPresent(u->{
    var auth=new UsernamePasswordAuthenticationToken(u.getEmail(),null,List.of(new SimpleGrantedAuthority("ROLE_"+u.getRole().name())));
    SecurityContextHolder.getContext().setAuthentication(auth);
   });} catch(RuntimeException ignored) { /* Token inválido: a rota protegida responderá 401. */ }
  }
  chain.doFilter(request,response);
 }
}
