package ao.solven.api.protect;

import ao.solven.api.audit.AuditLog;
import ao.solven.api.audit.AuditLogRepository;
import ao.solven.api.enrollment.*;
import ao.solven.api.user.*;
import jakarta.transaction.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@Service
public class ProtectionCaseService {
 private final ProtectionCaseRepository cases; private final EnrollmentRepository enrollments; private final UserAccountRepository users; private final AuditLogRepository audit; private final ProtectionEvidenceRepository evidence;
 public ProtectionCaseService(ProtectionCaseRepository cases,EnrollmentRepository enrollments,UserAccountRepository users,AuditLogRepository audit,ProtectionEvidenceRepository evidence){this.cases=cases;this.enrollments=enrollments;this.users=users;this.audit=audit;this.evidence=evidence;}
 @Transactional public CaseView open(String email,OpenCaseRequest r){
  Enrollment e=enrollments.findById(r.enrollmentId()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Inscrição não encontrada"));
  if(!e.getStudent().getEmail().equals(email))throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Apenas o estudante inscrito pode abrir esta reclamação");
  if(e.getStatus()==EnrollmentStatus.CANCELLED)throw new ResponseStatusException(HttpStatus.CONFLICT,"Inscrição cancelada não permite nova reclamação");
  if(cases.existsByEnrollmentIdAndStatusIn(e.getId(),List.of(ProtectionCaseStatus.OPEN,ProtectionCaseStatus.UNDER_REVIEW,ProtectionCaseStatus.WAITING_FOR_STUDENT,ProtectionCaseStatus.WAITING_FOR_TEACHER)))throw new ResponseStatusException(HttpStatus.CONFLICT,"Já existe uma reclamação em aberto para esta inscrição");
  ProtectionCase c=cases.save(new ProtectionCase(e,e.getStudent(),e.getCourse().getTeacher(),r.claimType().trim(),r.description().trim(),r.requestedResolution()));
  audit.save(new AuditLog(e.getStudent().getId(),"PROTECTION_CASE_OPENED","PROTECTION_CASE",c.getId(),"{\"note\":\"Reclamação aberta; sem movimentação financeira automática\"}")); return view(c);
 }
 @Transactional public CaseView statement(Long id,String email,String statement){ProtectionCase c=cases.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));boolean student=c.getStudent().getEmail().equals(email);boolean teacher=c.getTeacher().getEmail().equals(email);if(!student&&!teacher)throw new ResponseStatusException(HttpStatus.FORBIDDEN);if(c.getStatus()==ProtectionCaseStatus.CLOSED||c.getStatus()==ProtectionCaseStatus.RESOLVED_STUDENT||c.getStatus()==ProtectionCaseStatus.RESOLVED_TEACHER)throw new ResponseStatusException(HttpStatus.CONFLICT,"Processo encerrado");c.addStatement(student,statement.trim());audit.save(new AuditLog(student?c.getStudent().getId():c.getTeacher().getId(),"PROTECTION_STATEMENT_ADDED","PROTECTION_CASE",id,student?"{\"note\":\"Declaração do estudante\"}":"{\"note\":\"Declaração do professor\"}"));return view(c);}
 @Transactional public CaseView adminReview(Long id,String adminEmail,ReviewCaseRequest r){ProtectionCase c=cases.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));UserAccount admin=users.findByEmail(adminEmail).orElseThrow();if(!List.of(ProtectionCaseStatus.UNDER_REVIEW,ProtectionCaseStatus.WAITING_FOR_STUDENT,ProtectionCaseStatus.WAITING_FOR_TEACHER,ProtectionCaseStatus.RESOLVED_STUDENT,ProtectionCaseStatus.RESOLVED_TEACHER,ProtectionCaseStatus.CLOSED).contains(r.status()))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Estado inválido");c.review(r.status(),r.decision().trim(),admin);audit.save(new AuditLog(admin.getId(),"PROTECTION_CASE_REVIEWED","PROTECTION_CASE",id,"{\"note\":\"Decisão registada; qualquer reembolso ou retenção depende do parceiro financeiro\"}"));return view(c);}
 @Transactional public EvidenceView addEvidence(Long id,String email,EvidenceRequest r){ProtectionCase c=cases.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));UserAccount actor=users.findByEmail(email).orElseThrow();if(!c.getStudent().getId().equals(actor.getId())&&!c.getTeacher().getId().equals(actor.getId()))throw new ResponseStatusException(HttpStatus.FORBIDDEN);if(c.getStatus()==ProtectionCaseStatus.CLOSED||c.getStatus()==ProtectionCaseStatus.RESOLVED_STUDENT||c.getStatus()==ProtectionCaseStatus.RESOLVED_TEACHER)throw new ResponseStatusException(HttpStatus.CONFLICT,"Processo encerrado");ProtectionEvidence saved=evidence.save(new ProtectionEvidence(c,actor,r.description().trim(),null));audit.save(new AuditLog(actor.getId(),"PROTECTION_EVIDENCE_ADDED","PROTECTION_CASE",id,"{\"note\":\"Metadados de evidência registados\"}"));return evidenceView(saved);}
 public List<EvidenceView> evidence(Long id,String email){ProtectionCase c=cases.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));if(!c.getStudent().getEmail().equals(email)&&!c.getTeacher().getEmail().equals(email))throw new ResponseStatusException(HttpStatus.FORBIDDEN);return evidence.findByProtectionCaseIdOrderByCreatedAtAsc(id).stream().map(this::evidenceView).toList();}
 private EvidenceView evidenceView(ProtectionEvidence e){return new EvidenceView(e.getId(),e.getSubmittedBy(),e.getDescription(),e.getStorageReference(),e.getCreatedAt());}
 public List<CaseView> mine(String email){return cases.findByStudentEmailOrTeacherEmailOrderByCreatedAtDesc(email,email).stream().map(this::view).toList();}
 public List<CaseView> all(){return cases.findAllByOrderByCreatedAtDesc().stream().map(this::view).toList();}
 private CaseView view(ProtectionCase c){return new CaseView(c.getId(),c.getEnrollment().getId(),c.getStudent().getFullName(),c.getTeacher().getFullName(),c.getClaimType(),c.getDescription(),c.getRequestedResolution(),c.getStatus().name(),c.getStudentStatement(),c.getTeacherStatement(),c.getAdminDecision(),c.getFinancialAction(),c.getCreatedAt());}
 public record OpenCaseRequest(@jakarta.validation.constraints.NotNull Long enrollmentId,@jakarta.validation.constraints.NotBlank @jakarta.validation.constraints.Size(max=50) String claimType,@jakarta.validation.constraints.NotBlank @jakarta.validation.constraints.Size(max=2000) String description,@jakarta.validation.constraints.Size(max=500) String requestedResolution){}
 public record EvidenceRequest(@jakarta.validation.constraints.NotBlank @jakarta.validation.constraints.Size(max=1200) String description){}
 public record EvidenceView(Long id,String submittedBy,String description,String storageReference,java.time.LocalDateTime createdAt){}
 public record StatementRequest(@jakarta.validation.constraints.NotBlank @jakarta.validation.constraints.Size(max=3000) String statement){}
 public record ReviewCaseRequest(@jakarta.validation.constraints.NotNull ProtectionCaseStatus status,@jakarta.validation.constraints.NotBlank @jakarta.validation.constraints.Size(max=3000) String decision){}
 public record CaseView(Long id,Long enrollmentId,String studentName,String teacherName,String claimType,String description,String requestedResolution,String status,String studentStatement,String teacherStatement,String adminDecision,String financialAction,java.time.LocalDateTime createdAt){}
}
