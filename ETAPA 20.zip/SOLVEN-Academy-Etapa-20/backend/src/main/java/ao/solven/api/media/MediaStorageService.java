package ao.solven.api.media;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.*;
import java.util.UUID;

@Service
public class MediaStorageService {
    private final Path root;
    public MediaStorageService(@Value("${solven.media.storage-dir:./solven-storage}") String directory) throws IOException {
        this.root = Paths.get(directory).toAbsolutePath().normalize();
        Files.createDirectories(root);
    }
    public String store(MultipartFile file) throws IOException {
        String key = UUID.randomUUID().toString();
        Path target = root.resolve(key).normalize();
        if (!target.getParent().equals(root)) throw new IOException("Caminho de armazenamento inválido.");
        try (var in = file.getInputStream()) { Files.copy(in, target); }
        return key;
    }
    public Path resolveForRead(String key) throws IOException {
        Path target = root.resolve(key).normalize();
        if (!target.getParent().equals(root) || !Files.isRegularFile(target)) throw new NoSuchFileException("Ficheiro não encontrado.");
        return target;
    }
    public void delete(String key) throws IOException {
        Path target = root.resolve(key).normalize();
        if (target.getParent().equals(root)) Files.deleteIfExists(target);
    }
}
