package ao.solven.api.enrollment;
public enum EnrollmentStatus { PENDING, ACTIVE, CANCELLED, COMPLETED }
