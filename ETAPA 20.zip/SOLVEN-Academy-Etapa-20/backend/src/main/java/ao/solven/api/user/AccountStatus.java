package ao.solven.api.user;
public enum AccountStatus { ACTIVE, SUSPENDED, PENDING }
