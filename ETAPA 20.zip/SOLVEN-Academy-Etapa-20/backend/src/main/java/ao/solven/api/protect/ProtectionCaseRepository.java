package ao.solven.api.protect;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ProtectionCaseRepository extends JpaRepository<ProtectionCase,Long> {
 List<ProtectionCase> findByStudentEmailOrTeacherEmailOrderByCreatedAtDesc(String studentEmail,String teacherEmail);
 List<ProtectionCase> findAllByOrderByCreatedAtDesc();
 boolean existsByEnrollmentIdAndStatusIn(Long enrollmentId, java.util.Collection<ProtectionCaseStatus> statuses);
}
