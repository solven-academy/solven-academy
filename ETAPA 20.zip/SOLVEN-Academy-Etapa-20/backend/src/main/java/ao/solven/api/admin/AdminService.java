package ao.solven.api.admin;

import ao.solven.api.audit.*;
import ao.solven.api.course.*;
import ao.solven.api.user.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@Service
public class AdminService {
    private final UserAccountRepository users;
    private final CourseRepository courses;
    private final AuditLogRepository audit;
    public AdminService(UserAccountRepository users, CourseRepository courses, AuditLogRepository audit){this.users=users;this.courses=courses;this.audit=audit;}

    @Transactional(readOnly=true)
    public Dashboard dashboard(){return new Dashboard(users.count(), users.countByRole(AccountRole.STUDENT), users.countByRole(AccountRole.TEACHER), courses.count(), courses.countByStatus(CourseStatus.PENDING), courses.countByStatus(CourseStatus.APPROVED), courses.countByStatus(CourseStatus.REJECTED), users.countByAccountStatus(AccountStatus.SUSPENDED));}

    @Transactional(readOnly=true)
    public List<AdminCourse> pendingCourses(){return courses.findByStatusOrderByCreatedAtDesc(CourseStatus.PENDING).stream().map(AdminCourse::from).toList();}

    @Transactional
    public AdminCourse reviewCourse(Long courseId, String adminEmail, ReviewRequest request){
        Course course=courses.findById(courseId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso não encontrado."));
        if(request==null || request.decision()==null || !(request.decision().equals("APPROVE") || request.decision().equals("REJECT"))) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Decisão inválida.");
        if(course.getStatus()!=CourseStatus.PENDING) throw new ResponseStatusException(HttpStatus.CONFLICT,"Este curso já foi analisado.");
        UserAccount admin=users.findByEmail(adminEmail).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));
        CourseStatus next=request.decision().equals("APPROVE")?CourseStatus.APPROVED:CourseStatus.REJECTED;
        String reason=request.reason()==null?null:request.reason().trim();
        if(next==CourseStatus.REJECTED && (reason==null || reason.length()<10)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Indique um motivo com pelo menos 10 caracteres.");
        course.review(next,admin,reason);
        Course saved=courses.save(course);
        audit.save(new AuditLog(admin.getId(), next.name(), "COURSE", saved.getId(), reason==null?null:"{\"reason\":\""+escape(reason)+"\"}"));
        return AdminCourse.from(saved);
    }

    @Transactional(readOnly=true)
    public List<AdminUser> users(){return users.findAllByOrderByCreatedAtDesc().stream().map(AdminUser::from).toList();}

    @Transactional
    public AdminUser changeUserStatus(Long userId, String adminEmail, StatusRequest request){
        UserAccount target=users.findById(userId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Utilizador não encontrado."));
        UserAccount admin=users.findByEmail(adminEmail).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));
        if(request==null || request.status()==null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Estado inválido.");
        if(target.getId().equals(admin.getId())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Não podes suspender a tua própria conta.");
        if(target.getRole()==AccountRole.ADMIN && request.status()==AccountStatus.SUSPENDED){
            long activeAdmins=users.countByRoleAndAccountStatus(AccountRole.ADMIN,AccountStatus.ACTIVE);
            if(target.getAccountStatus()==AccountStatus.ACTIVE && activeAdmins<=1) throw new ResponseStatusException(HttpStatus.CONFLICT,"Não é possível suspender o último administrador activo.");
        }
        target.setAccountStatus(request.status());
        users.save(target);
        audit.save(new AuditLog(admin.getId(),"ACCOUNT_STATUS_CHANGED","USER",target.getId(),"{\"status\":\""+request.status().name()+"\"}"));
        return AdminUser.from(target);
    }

    @Transactional(readOnly=true)
    public List<AuditEntry> recentActivity(){return audit.findTop50ByOrderByCreatedAtDesc().stream().map(AuditEntry::from).toList();}

    private static String escape(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ").replace("\r"," ");}
    public record Dashboard(long totalUsers,long students,long teachers,long totalCourses,long pendingCourses,long approvedCourses,long rejectedCourses,long suspendedUsers){}
    public record AdminCourse(Long id,String title,String description,String level,String priceAoa,String status,Long categoryId,String categoryName,String teacherName,String teacherEmail,String createdAt,String rejectionReason){
        static AdminCourse from(Course c){return new AdminCourse(c.getId(),c.getTitle(),c.getDescription(),c.getLevel().name(),c.getPriceAoa().toPlainString(),c.getStatus().name(),c.getCategory().getId(),c.getCategory().getName(),c.getTeacher().getFullName(),c.getTeacher().getEmail(),c.getCreatedAt()==null?null:c.getCreatedAt().toString(),c.getRejectionReason());}
    }
    public record AdminUser(Long id,String fullName,String email,String role,String status,String createdAt){static AdminUser from(UserAccount u){return new AdminUser(u.getId(),u.getFullName(),u.getEmail(),u.getRole().name(),u.getAccountStatus().name(),u.getCreatedAt()==null?null:u.getCreatedAt().toString());}}
    public record AuditEntry(Long id,Long actorUserId,String action,String entityType,Long entityId,String details,String createdAt){static AuditEntry from(AuditLog a){return new AuditEntry(a.getId(),a.getActorUserId(),a.getAction(),a.getEntityType(),a.getEntityId(),a.getDetails(),a.getCreatedAt()==null?null:a.getCreatedAt().toString());}}
    public record ReviewRequest(String decision,String reason){}
    public record StatusRequest(AccountStatus status){}
}
