package ao.solven.api.solvia;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity @Table(name="solvia_conversations")
public class SolviaConversation {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(name="user_id",nullable=false) private Long userId;
 @Column(nullable=false,length=160) private String title;
 @Column(name="created_at",insertable=false,updatable=false) private LocalDateTime createdAt;
 @Column(name="updated_at",insertable=false,updatable=false) private LocalDateTime updatedAt;
 protected SolviaConversation(){}
 public SolviaConversation(Long userId,String title){this.userId=userId;this.title=title;}
 public Long getId(){return id;} public Long getUserId(){return userId;} public String getTitle(){return title;} public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}