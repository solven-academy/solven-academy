package ao.solven.api.admin;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    private final AdminService service;
    public AdminController(AdminService service){this.service=service;}
    @GetMapping("/dashboard") public AdminService.Dashboard dashboard(){return service.dashboard();}
    @GetMapping("/courses/pending") public List<AdminService.AdminCourse> pending(){return service.pendingCourses();}
    @PostMapping("/courses/{id}/review") public AdminService.AdminCourse review(@PathVariable Long id,@RequestBody AdminService.ReviewRequest request,Authentication auth){return service.reviewCourse(id,auth.getName(),request);}
    @GetMapping("/users") public List<AdminService.AdminUser> users(){return service.users();}
    @PatchMapping("/users/{id}/status") public AdminService.AdminUser status(@PathVariable Long id,@RequestBody AdminService.StatusRequest request,Authentication auth){return service.changeUserStatus(id,auth.getName(),request);}
    @GetMapping("/activity") public List<AdminService.AuditEntry> activity(){return service.recentActivity();}
}
