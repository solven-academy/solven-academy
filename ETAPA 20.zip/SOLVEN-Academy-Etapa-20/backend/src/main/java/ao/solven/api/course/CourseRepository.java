package ao.solven.api.course;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface CourseRepository extends JpaRepository<Course,Long> {
 List<Course> findByStatusOrderByCreatedAtDesc(CourseStatus status);
 long countByStatus(CourseStatus status);
 List<Course> findByTeacherEmailOrderByCreatedAtDesc(String email);
 List<Course> findByStatusAndCategoryIdOrderByCreatedAtDesc(CourseStatus status, Long categoryId);
}
