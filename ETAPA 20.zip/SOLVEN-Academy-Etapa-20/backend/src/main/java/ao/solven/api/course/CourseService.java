package ao.solven.api.course;
import ao.solven.api.user.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
@Service
public class CourseService {
 private final CourseRepository courses; private final CategoryRepository categories; private final UserAccountRepository users;
 public CourseService(CourseRepository courses, CategoryRepository categories, UserAccountRepository users){this.courses=courses;this.categories=categories;this.users=users;}
 @Transactional(readOnly=true) public List<Category> categories(){return categories.findByActiveTrueOrderByNameAsc();}
 @Transactional public CourseResponse create(String email, CreateCourseRequest r){
  UserAccount teacher=users.findByEmail(email).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));
  if(teacher.getRole()!=AccountRole.TEACHER) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Apenas professores podem publicar cursos.");
  Category category=categories.findById(r.categoryId()).filter(Category::isActive).orElseThrow(()->new ResponseStatusException(HttpStatus.BAD_REQUEST,"Categoria inválida ou inactiva."));
  Course c=new Course(teacher,category,r.title().trim(),r.description().trim(),r.level(),r.priceAoa());
  return CourseResponse.from(courses.save(c));
 }
 @Transactional(readOnly=true) public List<CourseResponse> publicCourses(Long categoryId){
  List<Course> found=categoryId==null?courses.findByStatusOrderByCreatedAtDesc(CourseStatus.APPROVED):courses.findByStatusAndCategoryIdOrderByCreatedAtDesc(CourseStatus.APPROVED,categoryId);
  return found.stream().map(CourseResponse::from).toList();
 }
 @Transactional(readOnly=true) public List<CourseResponse> mine(String email){return courses.findByTeacherEmailOrderByCreatedAtDesc(email).stream().map(CourseResponse::from).toList();}
 @Transactional(readOnly=true) public CourseResponse publicCourse(Long id){Course c=courses.findById(id).filter(x->x.getStatus()==CourseStatus.APPROVED).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso não encontrado."));return CourseResponse.from(c);}
}
