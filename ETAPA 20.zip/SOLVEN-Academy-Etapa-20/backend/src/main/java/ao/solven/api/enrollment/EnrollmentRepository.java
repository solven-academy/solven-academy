package ao.solven.api.enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    Optional<Enrollment> findByStudentEmailAndCourseId(String email, Long courseId);
    List<Enrollment> findByStudentEmailOrderByEnrolledAtDesc(String email);
    List<Enrollment> findByCourseIdOrderByEnrolledAtDesc(Long courseId);
}
