package ao.solven.api.solvia;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface SolviaConversationRepository extends JpaRepository<SolviaConversation,Long>{
 List<SolviaConversation> findTop50ByUserIdOrderByIdDesc(Long userId);
 Optional<SolviaConversation> findByIdAndUserId(Long id,Long userId);
}