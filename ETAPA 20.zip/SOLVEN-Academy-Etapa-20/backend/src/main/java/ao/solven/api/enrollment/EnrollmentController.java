package ao.solven.api.enrollment;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api")
public class EnrollmentController {
    private final EnrollmentService service;
    public EnrollmentController(EnrollmentService service) { this.service = service; }
    @PostMapping("/student/enrollments/{courseId}") @ResponseStatus(HttpStatus.CREATED)
    public EnrollmentResponse enroll(@PathVariable Long courseId, Authentication auth) { return service.enroll(auth.getName(), courseId); }
    @GetMapping("/student/enrollments")
    public List<EnrollmentResponse> mine(Authentication auth) { return service.mine(auth.getName()); }
    @GetMapping("/teacher/courses/{courseId}/students")
    public List<EnrollmentService.StudentEnrollmentView> students(@PathVariable Long courseId, Authentication auth) { return service.studentsForTeacher(auth.getName(), courseId); }
}
