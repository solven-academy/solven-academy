package ao.solven.api.media;

import jakarta.validation.constraints.NotNull;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;

@RestController @RequestMapping("/api/courses/{courseId}/media")
public class MediaAssetController {
    private final MediaAssetService service;
    public MediaAssetController(MediaAssetService service){this.service=service;}
    @PostMapping(consumes=MediaType.MULTIPART_FORM_DATA_VALUE) @ResponseStatus(HttpStatus.CREATED)
    public MediaAssetService.MediaView upload(@PathVariable Long courseId,@RequestPart("file") @NotNull MultipartFile file,Authentication auth){return service.upload(courseId,auth.getName(),file);}
    @GetMapping public List<MediaAssetService.MediaView> list(@PathVariable Long courseId,Authentication auth){return service.list(courseId,auth.getName());}
    @GetMapping("/{mediaId}/content")
    public ResponseEntity<FileSystemResource> download(@PathVariable Long courseId,@PathVariable Long mediaId,Authentication auth){
        var result=service.download(courseId,mediaId,auth.getName()); var a=result.asset();
        return ResponseEntity.ok().contentType(MediaType.parseMediaType(a.getContentType())).contentLength(a.getFileSize())
            .header(HttpHeaders.CONTENT_DISPOSITION,ContentDisposition.inline().filename(a.getOriginalName()).build().toString())
            .header(HttpHeaders.X_CONTENT_TYPE_OPTIONS,"nosniff").body(new FileSystemResource(result.path()));
    }
    @DeleteMapping("/{mediaId}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long courseId,@PathVariable Long mediaId,Authentication auth){service.delete(courseId,mediaId,auth.getName());}
}
