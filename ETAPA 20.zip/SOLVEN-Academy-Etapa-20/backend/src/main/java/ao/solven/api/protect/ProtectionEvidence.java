package ao.solven.api.protect;
import ao.solven.api.user.UserAccount;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity @Table(name="protection_evidence")
public class ProtectionEvidence {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="case_id",nullable=false) private ProtectionCase protectionCase;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="submitted_by",nullable=false) private UserAccount submittedBy;
 @Column(nullable=false,length=1200) private String description;
 @Column(name="storage_reference",length=500) private String storageReference;
 @Column(name="created_at",insertable=false,updatable=false) private LocalDateTime createdAt;
 protected ProtectionEvidence(){}
 public ProtectionEvidence(ProtectionCase c,UserAccount u,String d,String ref){protectionCase=c;submittedBy=u;description=d;storageReference=ref;}
 public Long getId(){return id;} public String getDescription(){return description;} public String getStorageReference(){return storageReference;} public String getSubmittedBy(){return submittedBy.getFullName();} public LocalDateTime getCreatedAt(){return createdAt;}
}
