package ao.solven.api.live;
public enum LiveSessionStatus { SCHEDULED, LIVE, ENDED, CANCELLED }
