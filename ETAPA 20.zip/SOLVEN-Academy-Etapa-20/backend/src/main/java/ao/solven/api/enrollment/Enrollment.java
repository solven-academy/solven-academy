package ao.solven.api.enrollment;

import ao.solven.api.course.Course;
import ao.solven.api.user.UserAccount;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "enrollments", uniqueConstraints = @UniqueConstraint(name = "uq_student_course", columnNames = {"student_id", "course_id"}))
public class Enrollment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "student_id", nullable = false)
    private UserAccount student;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "course_id", nullable = false)
    private Course course;
    @Enumerated(EnumType.STRING) @Column(name = "enrollment_status", nullable = false, length = 20)
    private EnrollmentStatus status = EnrollmentStatus.PENDING;
    @Column(name = "enrolled_at", insertable = false, updatable = false)
    private LocalDateTime enrolledAt;
    protected Enrollment() {}
    public Enrollment(UserAccount student, Course course, EnrollmentStatus status) { this.student = student; this.course = course; this.status = status; }
    public Long getId() { return id; }
    public UserAccount getStudent() { return student; }
    public Course getCourse() { return course; }
    public EnrollmentStatus getStatus() { return status; }
    public LocalDateTime getEnrolledAt() { return enrolledAt; }
    public void setStatus(EnrollmentStatus status) { this.status = status; }
}
