package ao.solven.api.course;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
public record CreateCourseRequest(
 @NotBlank @Size(min=4,max=180) String title,
 @NotBlank @Size(min=20,max=5000) String description,
 @NotNull Long categoryId,
 @NotNull CourseLevel level,
 @NotNull @DecimalMin("0.00") @Digits(integer=10,fraction=2) BigDecimal priceAoa
) {}
