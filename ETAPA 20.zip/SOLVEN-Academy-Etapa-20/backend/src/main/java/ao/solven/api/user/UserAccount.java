package ao.solven.api.user;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "users")
public class UserAccount {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true, length = 254)
    private String email;
    @Column(name = "password_hash", nullable = false, length = 255)
    private String passwordHash;
    @Column(name = "full_name", nullable = false, length = 120)
    private String fullName;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20)
    private AccountRole role;
    @Enumerated(EnumType.STRING) @Column(name = "account_status", nullable = false, length = 20)
    private AccountStatus accountStatus = AccountStatus.ACTIVE;
    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
    public Long getId(){return id;} public String getEmail(){return email;}
    public void setEmail(String v){email=v;} public String getPasswordHash(){return passwordHash;}
    public void setPasswordHash(String v){passwordHash=v;} public String getFullName(){return fullName;}
    public void setFullName(String v){fullName=v;} public AccountRole getRole(){return role;}
    public void setRole(AccountRole v){role=v;} public AccountStatus getAccountStatus(){return accountStatus;}
    public void setAccountStatus(AccountStatus v){accountStatus=v;} public LocalDateTime getCreatedAt(){return createdAt;}
}
