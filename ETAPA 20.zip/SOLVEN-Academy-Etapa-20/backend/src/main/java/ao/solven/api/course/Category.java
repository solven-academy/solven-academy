package ao.solven.api.course;
import jakarta.persistence.*;
@Entity
@Table(name="categories")
public class Category {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false, unique=true, length=100) private String name;
 @Column(nullable=false, unique=true, length=120) private String slug;
 @Column(name="is_active", nullable=false) private boolean active=true;
 public Long getId(){return id;} public String getName(){return name;} public String getSlug(){return slug;} public boolean isActive(){return active;}
}
