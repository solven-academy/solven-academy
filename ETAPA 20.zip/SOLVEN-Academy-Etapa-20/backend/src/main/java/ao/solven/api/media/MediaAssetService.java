package ao.solven.api.media;

import ao.solven.api.course.*;
import ao.solven.api.enrollment.*;
import ao.solven.api.user.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import java.io.IOException;
import java.util.*;

@Service
public class MediaAssetService {
    private static final long MAX_BYTES = 500L * 1024 * 1024;
    private static final Map<String,MediaType> ALLOWED = Map.of(
        "video/mp4",MediaType.VIDEO, "video/webm",MediaType.VIDEO,
        "application/pdf",MediaType.DOCUMENT,
        "image/jpeg",MediaType.IMAGE, "image/png",MediaType.IMAGE, "image/webp",MediaType.IMAGE
    );
    private final MediaAssetRepository mediaRepo; private final CourseRepository courseRepo; private final UserAccountRepository userRepo;
    private final EnrollmentRepository enrollmentRepo; private final MediaStorageService storage;
    public MediaAssetService(MediaAssetRepository mediaRepo, CourseRepository courseRepo, UserAccountRepository userRepo, EnrollmentRepository enrollmentRepo, MediaStorageService storage) {
        this.mediaRepo=mediaRepo; this.courseRepo=courseRepo; this.userRepo=userRepo; this.enrollmentRepo=enrollmentRepo; this.storage=storage;
    }
    @Transactional
    public MediaView upload(Long courseId, String email, MultipartFile file) {
        UserAccount user = user(email); if(user.getRole()!=AccountRole.TEACHER && user.getRole()!=AccountRole.ADMIN) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        Course course = courseRepo.findById(courseId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso não encontrado."));
        if(user.getRole()!=AccountRole.ADMIN && !course.getTeacher().getId().equals(user.getId())) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        if(file==null || file.isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Selecciona um ficheiro.");
        if(file.getSize()>MAX_BYTES) throw new ResponseStatusException(HttpStatus.PAYLOAD_TOO_LARGE,"O limite por ficheiro é 500 MB.");
        String type = Optional.ofNullable(file.getContentType()).orElse("").toLowerCase(Locale.ROOT);
        MediaType mediaType = ALLOWED.get(type);
        if(mediaType==null) throw new ResponseStatusException(HttpStatus.UNSUPPORTED_MEDIA_TYPE,"Formato não permitido. Usa MP4, WebM, PDF, JPG, PNG ou WEBP.");
        String original = Optional.ofNullable(file.getOriginalFilename()).orElse("ficheiro").replaceAll("[\\r\\n\\\\/]", "_");
        String key;
        try { key=storage.store(file); } catch(IOException e){throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"Não foi possível guardar o ficheiro.");}
        return view(mediaRepo.save(new MediaAsset(course,user,original,key,type,file.getSize(),mediaType)));
    }
    @Transactional(readOnly=true)
    public List<MediaView> list(Long courseId,String email){
        UserAccount user=user(email); Course course=courseRepo.findById(courseId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
        authorizeRead(user,course);
        return mediaRepo.findByCourseIdOrderByCreatedAtDesc(courseId).stream().map(this::view).toList();
    }
    @Transactional(readOnly=true)
    public Download download(Long courseId,Long mediaId,String email){
        UserAccount user=user(email); MediaAsset asset=mediaRepo.findByIdAndCourseId(mediaId,courseId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
        authorizeRead(user,asset.getCourse());
        try{return new Download(asset,storage.resolveForRead(asset.getStorageKey()));}catch(IOException e){throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Ficheiro indisponível.");}
    }
    @Transactional
    public void delete(Long courseId,Long mediaId,String email){
        UserAccount user=user(email); MediaAsset asset=mediaRepo.findByIdAndCourseId(mediaId,courseId).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
        if(user.getRole()!=AccountRole.ADMIN && !asset.getUploadedBy().getId().equals(user.getId())) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        try{storage.delete(asset.getStorageKey());}catch(IOException e){throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"Não foi possível eliminar o ficheiro.");}
        mediaRepo.delete(asset);
    }
    private void authorizeRead(UserAccount user,Course course){
        if(user.getRole()==AccountRole.ADMIN || course.getTeacher().getId().equals(user.getId())) return;
        if(course.getStatus()!=CourseStatus.APPROVED) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        boolean enrolled=enrollmentRepo.findByStudentEmailAndCourseId(user.getEmail(),course.getId()).filter(e->e.getStatus()==EnrollmentStatus.ACTIVE || e.getStatus()==EnrollmentStatus.COMPLETED).isPresent();
        if(!enrolled) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"É necessária uma inscrição activa neste curso.");
    }
    private UserAccount user(String email){return userRepo.findByEmail(email).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));}
    private MediaView view(MediaAsset a){return new MediaView(a.getId(),a.getCourse().getId(),a.getOriginalName(),a.getContentType(),a.getFileSize(),a.getMediaType(),a.getCreatedAt());}
    public record MediaView(Long id,Long courseId,String originalName,String contentType,long fileSize,MediaType mediaType,java.time.LocalDateTime createdAt){}
    public record Download(MediaAsset asset,java.nio.file.Path path){}
}
