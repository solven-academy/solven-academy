package ao.solven.api.live;

import ao.solven.api.course.Course;
import ao.solven.api.user.UserAccount;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="live_sessions")
public class LiveSession {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="course_id", nullable=false) private Course course;
    @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="teacher_id", nullable=false) private UserAccount teacher;
    @Column(nullable=false, length=180) private String title;
    @Column(length=1000) private String description;
    @Column(name="starts_at", nullable=false) private LocalDateTime startsAt;
    @Column(name="ends_at", nullable=false) private LocalDateTime endsAt;
    @Column(name="room_code", nullable=false, unique=true, length=64) private String roomCode;
    @Enumerated(EnumType.STRING) @Column(name="session_status", nullable=false, length=20) private LiveSessionStatus status=LiveSessionStatus.SCHEDULED;
    @Column(name="created_at", insertable=false, updatable=false) private LocalDateTime createdAt;
    protected LiveSession() {}
    public LiveSession(Course course, UserAccount teacher, String title, String description, LocalDateTime startsAt, LocalDateTime endsAt, String roomCode) {
        this.course=course; this.teacher=teacher; this.title=title; this.description=description; this.startsAt=startsAt; this.endsAt=endsAt; this.roomCode=roomCode;
    }
    public Long getId(){return id;} public Course getCourse(){return course;} public UserAccount getTeacher(){return teacher;}
    public String getTitle(){return title;} public String getDescription(){return description;} public LocalDateTime getStartsAt(){return startsAt;}
    public LocalDateTime getEndsAt(){return endsAt;} public String getRoomCode(){return roomCode;} public LiveSessionStatus getStatus(){return status;}
    public LocalDateTime getCreatedAt(){return createdAt;} public void setStatus(LiveSessionStatus status){this.status=status;}
}
