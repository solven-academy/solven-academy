package ao.solven.api.auth;

import ao.solven.api.user.UserAccount;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;

@Service
public class JwtService {
    private final SecretKey key;
    private final long ttlSeconds;
    public JwtService(@Value("${solven.jwt.secret}") String secret,
                      @Value("${solven.jwt.ttl-seconds:900}") long ttlSeconds) {
        if (secret == null || secret.getBytes(StandardCharsets.UTF_8).length < 32)
            throw new IllegalStateException("SOLVEN_JWT_SECRET deve ter pelo menos 32 bytes.");
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.ttlSeconds = ttlSeconds;
    }
    public String generate(UserAccount user) {
        Instant now = Instant.now();
        return Jwts.builder().subject(user.getEmail()).claim("uid", user.getId())
            .claim("role", user.getRole().name()).issuedAt(Date.from(now))
            .expiration(Date.from(now.plusSeconds(ttlSeconds))).signWith(key).compact();
    }
    public String extractSubject(String token) {
        return Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload().getSubject();
    }
    public long getTtlSeconds(){ return ttlSeconds; }
}
