package ao.solven.api.media;
public enum MediaType { VIDEO, DOCUMENT, IMAGE }
