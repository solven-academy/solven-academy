package ao.solven.api.media;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface MediaAssetRepository extends JpaRepository<MediaAsset,Long> {
    List<MediaAsset> findByCourseIdOrderByCreatedAtDesc(Long courseId);
    Optional<MediaAsset> findByIdAndCourseId(Long id, Long courseId);
}
