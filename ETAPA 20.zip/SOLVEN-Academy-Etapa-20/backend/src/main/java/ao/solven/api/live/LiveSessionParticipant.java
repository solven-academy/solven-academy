package ao.solven.api.live;
import ao.solven.api.user.UserAccount;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity @Table(name="live_session_participants", uniqueConstraints=@UniqueConstraint(name="uq_live_session_user", columnNames={"session_id","user_id"}))
public class LiveSessionParticipant {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="session_id", nullable=false) private LiveSession session;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="user_id", nullable=false) private UserAccount user;
 @Column(name="joined_at", nullable=false, insertable=false, updatable=false) private LocalDateTime joinedAt;
 @Column(name="left_at") private LocalDateTime leftAt;
 protected LiveSessionParticipant(){}
 public LiveSessionParticipant(LiveSession session, UserAccount user){this.session=session;this.user=user;}
 public Long getId(){return id;} public LiveSession getSession(){return session;} public UserAccount getUser(){return user;} public LocalDateTime getJoinedAt(){return joinedAt;} public LocalDateTime getLeftAt(){return leftAt;} public void setLeftAt(LocalDateTime value){leftAt=value;}
}
