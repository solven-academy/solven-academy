package ao.solven.api.audit;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="audit_logs")
public class AuditLog {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(name="actor_user_id") private Long actorUserId;
    @Column(nullable=false, length=100) private String action;
    @Column(name="entity_type", nullable=false, length=80) private String entityType;
    @Column(name="entity_id") private Long entityId;
    @Column(columnDefinition="JSON") private String details;
    @Column(name="created_at", insertable=false, updatable=false) private LocalDateTime createdAt;
    protected AuditLog() {}
    public AuditLog(Long actorUserId, String action, String entityType, Long entityId, String details) {
        this.actorUserId=actorUserId; this.action=action; this.entityType=entityType; this.entityId=entityId; this.details=details;
    }
    public Long getId(){return id;} public Long getActorUserId(){return actorUserId;}
    public String getAction(){return action;} public String getEntityType(){return entityType;}
    public Long getEntityId(){return entityId;} public String getDetails(){return details;}
    public LocalDateTime getCreatedAt(){return createdAt;}
}
