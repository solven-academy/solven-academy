package ao.solven.api.solvia;
import ao.solven.api.user.*;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClient;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;

@Service
public class SolviaService {
 private final SolviaConversationRepository conversations; private final SolviaMessageRepository messages; private final UserAccountRepository users; private final RestClient client;
 @Value("${solven.solvia.enabled:false}") private boolean enabled;
 @Value("${solven.solvia.api-key:}") private String apiKey;
 @Value("${solven.solvia.model:}") private String model;
 @Value("${solven.solvia.endpoint:https://api.openai.com/v1/chat/completions}") private String endpoint;
 public SolviaService(SolviaConversationRepository c,SolviaMessageRepository m,UserAccountRepository u){conversations=c;messages=m;users=u;client=RestClient.builder().build();}
 @Transactional
 public ChatView chat(String email,ChatRequest request){
  if(request==null||request.message()==null||request.message().isBlank()||request.message().length()>4000) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Mensagem inválida (máximo 4000 caracteres).");
  UserAccount user=users.findByEmail(email).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));
  if(!enabled||apiKey==null||apiKey.isBlank()||model==null||model.isBlank()) throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"SOLVIA ainda não está ligada a um fornecedor de IA.");
  SolviaConversation conversation;
  if(request.conversationId()==null){String title=request.message().replaceAll("\s+"," "); if(title.length()>150) title=title.substring(0,150); conversation=conversations.save(new SolviaConversation(user.getId(),title));}
  else conversation=conversations.findByIdAndUserId(request.conversationId(),user.getId()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
  messages.save(new SolviaMessage(conversation.getId(),"user",request.message().trim()));
  List<SolviaMessage> history=new ArrayList<>(messages.findTop12ByConversationIdOrderByIdDesc(conversation.getId())); Collections.reverse(history);
  List<Map<String,String>> prompt=new ArrayList<>(); prompt.add(Map.of("role","system","content",systemPrompt(user.getRole())));
  for(SolviaMessage item:history) prompt.add(Map.of("role",item.getRole(),"content",item.getContent()));
  Map<String,Object> payload=Map.of("model",model,"messages",prompt,"temperature",0.4,"max_tokens",1200);
  JsonNode response;
  try {response=client.post().uri(endpoint).contentType(MediaType.APPLICATION_JSON).header(HttpHeaders.AUTHORIZATION,"Bearer "+apiKey).body(payload).retrieve().body(JsonNode.class);}
  catch(Exception ex){throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,"O serviço de IA está temporariamente indisponível.");}
  JsonNode content=response==null?null:response.path("choices").path(0).path("message").path("content");
  if(content==null||!content.isTextual()||content.asText().isBlank()) throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,"O fornecedor não devolveu uma resposta válida.");
  String answer=content.asText(); if(answer.length()>12000) answer=answer.substring(0,12000);
  messages.save(new SolviaMessage(conversation.getId(),"assistant",answer));
  return new ChatView(conversation.getId(),conversation.getTitle(),answer);
 }
 @Transactional(readOnly=true) public List<ConversationView> list(String email){UserAccount u=users.findByEmail(email).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));return conversations.findTop50ByUserIdOrderByIdDesc(u.getId()).stream().map(c->new ConversationView(c.getId(),c.getTitle(),c.getCreatedAt())).toList();}
 @Transactional(readOnly=true) public List<MessageView> history(String email,Long id){UserAccount u=users.findByEmail(email).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));SolviaConversation c=conversations.findByIdAndUserId(id,u.getId()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));return messages.findByConversationIdOrderByIdAsc(c.getId()).stream().map(m->new MessageView(m.getId(),m.getRole(),m.getContent(),m.getCreatedAt())).toList();}
 private String systemPrompt(AccountRole role){String common="És a SOLVIA, assistente educativo da SOLVEN Academy. Responde em português claro, explica passo a passo, define termos difíceis entre parênteses, admite quando não sabes e não inventes fontes. Incentiva o aluno a compreender em vez de copiar. Não peças palavras-passe, dados bancários, documentos de identidade ou outros dados sensíveis. Não dês aconselhamento médico, jurídico ou financeiro personalizado; recomenda um adulto responsável ou profissional quando necessário. Mantém conteúdo adequado a estudantes e não forneças instruções perigosas, violentas, de fraude ou invasão de sistemas. Em cibersegurança, limita-te a aprendizagem defensiva e ambientes autorizados.";
  if(role==AccountRole.TEACHER)return common+" Apoias professores a preparar planos de aula, exercícios, avaliações e explicações. Não inventes qualificações nem atribuas notas finais automaticamente.";
  if(role==AccountRole.STUDENT)return common+" Apoias estudantes com explicações, exemplos, exercícios e revisão. Não afirmes que substituis o professor.";
  return common+" Para administradores, apoia apenas tarefas educativas e documentação.";
 }
 public record ChatRequest(Long conversationId,String message){} public record ChatView(Long conversationId,String title,String answer){} public record ConversationView(Long id,String title,java.time.LocalDateTime createdAt){} public record MessageView(Long id,String role,String content,java.time.LocalDateTime createdAt){}
}