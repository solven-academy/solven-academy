package ao.solven.api.admin;

import ao.solven.api.user.*;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.util.Locale;

/** Creates the first admin only when explicit environment credentials are supplied. */
@Component
public class AdminBootstrapRunner implements ApplicationRunner {
    private final UserAccountRepository users; private final PasswordEncoder encoder;
    public AdminBootstrapRunner(UserAccountRepository users,PasswordEncoder encoder){this.users=users;this.encoder=encoder;}
    @Override @Transactional public void run(ApplicationArguments args){
        String email=System.getenv("SOLVEN_ADMIN_EMAIL"); String password=System.getenv("SOLVEN_ADMIN_PASSWORD");
        if(email==null || email.isBlank() || password==null || password.length()<16) return;
        email=email.trim().toLowerCase(Locale.ROOT);
        if(users.existsByEmail(email)) return;
        UserAccount admin=new UserAccount(); admin.setFullName("Administrador SOLVEN"); admin.setEmail(email);
        admin.setPasswordHash(encoder.encode(password)); admin.setRole(AccountRole.ADMIN); admin.setAccountStatus(AccountStatus.ACTIVE); users.save(admin);
        System.out.println("Conta administrativa inicial criada para: "+email);
    }
}
