package ao.solven.api.solvia;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity @Table(name="solvia_messages")
public class SolviaMessage {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(name="conversation_id",nullable=false) private Long conversationId;
 @Column(nullable=false,length=16) private String role;
 @Column(nullable=false,columnDefinition="TEXT") private String content;
 @Column(name="created_at",insertable=false,updatable=false) private LocalDateTime createdAt;
 protected SolviaMessage(){}
 public SolviaMessage(Long conversationId,String role,String content){this.conversationId=conversationId;this.role=role;this.content=content;}
 public Long getId(){return id;} public Long getConversationId(){return conversationId;} public String getRole(){return role;} public String getContent(){return content;} public LocalDateTime getCreatedAt(){return createdAt;}
}