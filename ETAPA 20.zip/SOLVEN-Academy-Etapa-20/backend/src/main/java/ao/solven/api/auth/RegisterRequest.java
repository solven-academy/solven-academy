package ao.solven.api.auth;
import ao.solven.api.user.AccountRole;
import jakarta.validation.constraints.*;
public record RegisterRequest(
 @NotBlank @Size(min=2,max=120) String fullName,
 @NotBlank @Email @Size(max=254) String email,
 @NotBlank @Size(min=12,max=72) String password,
 @NotNull AccountRole role
) {}
