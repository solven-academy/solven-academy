package ao.solven.api.course;
import ao.solven.api.user.UserAccount;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
@Entity
@Table(name="courses")
public class Course {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="teacher_id", nullable=false) private UserAccount teacher;
 @ManyToOne(fetch=FetchType.EAGER, optional=false) @JoinColumn(name="category_id", nullable=false) private Category category;
 @Column(nullable=false, length=180) private String title;
 @Column(nullable=false, columnDefinition="TEXT") private String description;
 @Enumerated(EnumType.STRING) @Column(nullable=false, length=20) private CourseLevel level;
 @Column(name="price_aoa", nullable=false, precision=12, scale=2) private BigDecimal priceAoa;
 @Enumerated(EnumType.STRING) @Column(nullable=false, length=20) private CourseStatus status=CourseStatus.PENDING;
 @Column(name="rejection_reason", length=500) private String rejectionReason;
 @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="reviewed_by") private UserAccount reviewedBy;
 @Column(name="reviewed_at") private LocalDateTime reviewedAt;
 @Column(name="created_at", insertable=false, updatable=false) private LocalDateTime createdAt;
 protected Course() {}
 public Course(UserAccount teacher, Category category, String title, String description, CourseLevel level, BigDecimal priceAoa){this.teacher=teacher;this.category=category;this.title=title;this.description=description;this.level=level;this.priceAoa=priceAoa;this.status=CourseStatus.PENDING;}
 public Long getId(){return id;} public UserAccount getTeacher(){return teacher;} public Category getCategory(){return category;} public String getTitle(){return title;} public String getDescription(){return description;} public CourseLevel getLevel(){return level;} public BigDecimal getPriceAoa(){return priceAoa;} public CourseStatus getStatus(){return status;} public LocalDateTime getCreatedAt(){return createdAt;} public String getRejectionReason(){return rejectionReason;} public UserAccount getReviewedBy(){return reviewedBy;} public LocalDateTime getReviewedAt(){return reviewedAt;}
 public void review(CourseStatus newStatus, UserAccount reviewer, String reason){this.status=newStatus;this.reviewedBy=reviewer;this.reviewedAt=LocalDateTime.now();this.rejectionReason=reason;}
}
