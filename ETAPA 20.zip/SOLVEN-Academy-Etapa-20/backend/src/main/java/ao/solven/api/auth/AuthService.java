package ao.solven.api.auth;

import ao.solven.api.user.*;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.transaction.annotation.Transactional;
import java.util.Locale;

@Service
public class AuthService {
 private final UserAccountRepository users; private final PasswordEncoder encoder; private final JwtService jwt;
 public AuthService(UserAccountRepository users, PasswordEncoder encoder, JwtService jwt){this.users=users;this.encoder=encoder;this.jwt=jwt;}
 @Transactional
 public AuthResponse register(RegisterRequest r){
   String email=r.email().trim().toLowerCase(Locale.ROOT);
   if(r.role()==AccountRole.ADMIN) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Não é permitido criar contas administrativas pelo registo público.");
   if(users.existsByEmail(email)) throw new ResponseStatusException(HttpStatus.CONFLICT,"Este email já está registado.");
   UserAccount u=new UserAccount(); u.setFullName(r.fullName().trim()); u.setEmail(email);
   u.setPasswordHash(encoder.encode(r.password())); u.setRole(r.role()); u.setAccountStatus(AccountStatus.ACTIVE);
   users.save(u); return response(u);
 }
 @Transactional(readOnly=true)
 public AuthResponse login(LoginRequest r){
   String email=r.email().trim().toLowerCase(Locale.ROOT);
   UserAccount u=users.findByEmail(email).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Credenciais inválidas."));
   if(!encoder.matches(r.password(),u.getPasswordHash())) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Credenciais inválidas.");
   if(u.getAccountStatus()!=AccountStatus.ACTIVE) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"A conta não está activa.");
   return response(u);
 }
 private AuthResponse response(UserAccount u){return new AuthResponse(jwt.generate(u),"Bearer",jwt.getTtlSeconds(),new AuthResponse.UserSummary(u.getId(),u.getFullName(),u.getEmail(),u.getRole().name()));}
}
