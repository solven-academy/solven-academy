package ao.solven.api.solvia;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface SolviaMessageRepository extends JpaRepository<SolviaMessage,Long>{
 List<SolviaMessage> findTop12ByConversationIdOrderByIdDesc(Long conversationId);
 List<SolviaMessage> findByConversationIdOrderByIdAsc(Long conversationId);
}