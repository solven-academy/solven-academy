package ao.solven.api.solvia;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/solvia")
public class SolviaController {
 private final SolviaService service; public SolviaController(SolviaService service){this.service=service;}
 @PostMapping("/chat") @ResponseStatus(HttpStatus.OK) public SolviaService.ChatView chat(@Valid @RequestBody ChatBody body,Authentication auth){return service.chat(auth.getName(),new SolviaService.ChatRequest(body.conversationId(),body.message()));}
 @GetMapping("/conversations") public List<SolviaService.ConversationView> list(Authentication auth){return service.list(auth.getName());}
 @GetMapping("/conversations/{id}/messages") public List<SolviaService.MessageView> history(@PathVariable Long id,Authentication auth){return service.history(auth.getName(),id);}
 public record ChatBody(Long conversationId,@NotBlank @Size(max=4000) String message){}
}