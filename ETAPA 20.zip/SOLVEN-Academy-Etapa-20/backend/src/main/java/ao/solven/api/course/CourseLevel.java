package ao.solven.api.course;
public enum CourseLevel { BEGINNER, INTERMEDIATE, ADVANCED }
