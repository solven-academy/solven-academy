package ao.solven.api.live;

import ao.solven.api.course.*;
import ao.solven.api.enrollment.*;
import ao.solven.api.user.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class LiveSessionService {
 private final LiveSessionRepository sessions; private final LiveSessionParticipantRepository participants;
 private final CourseRepository courses; private final UserAccountRepository users; private final EnrollmentRepository enrollments;
 public LiveSessionService(LiveSessionRepository sessions,LiveSessionParticipantRepository participants,CourseRepository courses,UserAccountRepository users,EnrollmentRepository enrollments){this.sessions=sessions;this.participants=participants;this.courses=courses;this.users=users;this.enrollments=enrollments;}
 @Transactional
 public SessionView create(String email,CreateRequest req){
  UserAccount teacher=user(email); if(teacher.getRole()!=AccountRole.TEACHER) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Apenas professores podem agendar aulas.");
  if(!req.endsAt().isAfter(req.startsAt())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"A hora de fim deve ser posterior à hora de início.");
  if(req.startsAt().isBefore(LocalDateTime.now().minusMinutes(1))) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Não é possível agendar uma aula no passado.");
  Course course=courses.findById(req.courseId()).filter(c->c.getStatus()==CourseStatus.APPROVED).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Curso aprovado não encontrado."));
  if(!course.getTeacher().getEmail().equals(email)) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Só podes agendar aulas nos teus próprios cursos.");
  LiveSession saved=sessions.save(new LiveSession(course,teacher,req.title().trim(),req.description(),req.startsAt(),req.endsAt(),UUID.randomUUID().toString().replace("-","")));
  participants.save(new LiveSessionParticipant(saved,teacher)); return view(saved);
 }
 @Transactional(readOnly=true)
 public List<SessionView> mine(String email){UserAccount u=user(email); if(u.getRole()==AccountRole.TEACHER) return sessions.findByTeacherEmailOrderByStartsAtDesc(email).stream().map(this::view).toList();
  if(u.getRole()==AccountRole.STUDENT) return enrollments.findByStudentEmailOrderByEnrolledAtDesc(email).stream().filter(e->e.getStatus()==EnrollmentStatus.ACTIVE).flatMap(e->sessions.findByCourseIdOrderByStartsAtAsc(e.getCourse().getId()).stream()).distinct().map(this::view).toList();
  return sessions.findAll().stream().map(this::view).toList();}
 @Transactional
 public RoomView join(String email,Long id){UserAccount u=user(email); LiveSession s=sessions.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Aula não encontrada."));
  if(s.getStatus()==LiveSessionStatus.CANCELLED||s.getStatus()==LiveSessionStatus.ENDED) throw new ResponseStatusException(HttpStatus.CONFLICT,"Esta aula não está disponível.");
  boolean teacher=s.getTeacher().getEmail().equals(email);
  if(!teacher){if(u.getRole()!=AccountRole.STUDENT) throw new ResponseStatusException(HttpStatus.FORBIDDEN); boolean enrolled=enrollments.findByStudentEmailAndCourseId(email,s.getCourse().getId()).filter(e->e.getStatus()==EnrollmentStatus.ACTIVE).isPresent(); if(!enrolled) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"É necessária uma inscrição activa neste curso.");}
  if(participants.findBySessionIdAndUserEmail(id,email).isEmpty()) participants.save(new LiveSessionParticipant(s,u));
  return new RoomView(s.getId(),s.getTitle(),s.getRoomCode(),s.getStatus().name(),"NOT_CONFIGURED","A sala e as permissões estão preparadas. A transmissão de áudio/vídeo requer um serviço WebRTC ou SFU configurado.");
 }
 @Transactional public SessionView changeStatus(String email,Long id,LiveSessionStatus next){LiveSession s=sessions.findByIdAndTeacherEmail(id,email).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Aula não encontrada para este professor."));
  if(next==LiveSessionStatus.SCHEDULED) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Não é permitido voltar uma aula ao estado agendado.");
  if(s.getStatus()==LiveSessionStatus.ENDED||s.getStatus()==LiveSessionStatus.CANCELLED) throw new ResponseStatusException(HttpStatus.CONFLICT,"A aula já foi encerrada ou cancelada.");
  if(next==LiveSessionStatus.ENDED && s.getStatus()!=LiveSessionStatus.LIVE) throw new ResponseStatusException(HttpStatus.CONFLICT,"Só podes terminar uma aula que esteja ao vivo.");
  s.setStatus(next); return view(s);}
 private UserAccount user(String email){return users.findByEmail(email).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));}
 private SessionView view(LiveSession s){return new SessionView(s.getId(),s.getCourse().getId(),s.getCourse().getTitle(),s.getTeacher().getFullName(),s.getTitle(),s.getDescription(),s.getStartsAt(),s.getEndsAt(),s.getStatus().name(),participants.countBySessionId(s.getId()));}
 public record CreateRequest(@jakarta.validation.constraints.NotNull Long courseId,@jakarta.validation.constraints.NotBlank @jakarta.validation.constraints.Size(max=180) String title,@jakarta.validation.constraints.Size(max=1000) String description,@jakarta.validation.constraints.NotNull LocalDateTime startsAt,@jakarta.validation.constraints.NotNull LocalDateTime endsAt){}
 public record SessionView(Long id,Long courseId,String courseTitle,String teacherName,String title,String description,LocalDateTime startsAt,LocalDateTime endsAt,String status,long participantCount){}
 public record RoomView(Long sessionId,String title,String roomCode,String status,String mediaStatus,String message){}
}
