package ao.solven.api.protect;

import ao.solven.api.enrollment.Enrollment;
import ao.solven.api.user.UserAccount;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="protection_cases")
public class ProtectionCase {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="enrollment_id", nullable=false) private Enrollment enrollment;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="student_id", nullable=false) private UserAccount student;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="teacher_id", nullable=false) private UserAccount teacher;
 @Column(name="claim_type", nullable=false, length=50) private String claimType;
 @Column(nullable=false, length=2000) private String description;
 @Column(name="requested_resolution", length=500) private String requestedResolution;
 @Enumerated(EnumType.STRING) @Column(nullable=false, length=32) private ProtectionCaseStatus status=ProtectionCaseStatus.OPEN;
 @Column(name="student_statement", length=3000) private String studentStatement;
 @Column(name="teacher_statement", length=3000) private String teacherStatement;
 @Column(name="admin_decision", length=3000) private String adminDecision;
 @Column(name="financial_action", length=40) private String financialAction="NONE";
 @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="reviewed_by") private UserAccount reviewedBy;
 @Column(name="created_at", insertable=false, updatable=false) private LocalDateTime createdAt;
 @Column(name="updated_at", insertable=false, updatable=false) private LocalDateTime updatedAt;
 protected ProtectionCase() {}
 public ProtectionCase(Enrollment enrollment, UserAccount student, UserAccount teacher, String claimType, String description, String requestedResolution){this.enrollment=enrollment;this.student=student;this.teacher=teacher;this.claimType=claimType;this.description=description;this.requestedResolution=requestedResolution;}
 public void addStatement(boolean byStudent,String statement){if(byStudent)this.studentStatement=statement;else this.teacherStatement=statement; if(this.status==ProtectionCaseStatus.OPEN)this.status=ProtectionCaseStatus.UNDER_REVIEW;}
 public void review(ProtectionCaseStatus status,String decision,UserAccount admin){this.status=status;this.adminDecision=decision;this.reviewedBy=admin;}
 public Long getId(){return id;} public Enrollment getEnrollment(){return enrollment;} public UserAccount getStudent(){return student;} public UserAccount getTeacher(){return teacher;} public String getClaimType(){return claimType;} public String getDescription(){return description;} public String getRequestedResolution(){return requestedResolution;} public ProtectionCaseStatus getStatus(){return status;} public String getStudentStatement(){return studentStatement;} public String getTeacherStatement(){return teacherStatement;} public String getAdminDecision(){return adminDecision;} public String getFinancialAction(){return financialAction;} public LocalDateTime getCreatedAt(){return createdAt;}
}
