# SOLVEN Academy — Etapa 18

Esta versão acrescenta a SOLVIA AI à base recebida da Etapa 17. Mantém a Etapa 16 e a Etapa 17 no mesmo projecto.

Começa por ler `docs/ETAPA18-SOLVIA-AI.md`. A integração com IA está desligada por padrão e exige configuração segura no servidor.
